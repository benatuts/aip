package au.edu.uts.aip.todo;

import java.io.*;

public class Task implements Serializable {

    private String title;
    private String notes;
    private TaskList taskList;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public TaskList getTaskList() {
        return taskList;
    }

    public void setTaskList(TaskList newTaskList) {
        if (null != taskList) {
            taskList.removeTask(this);
        }
        newTaskList.addTask(this);
        taskList = newTaskList;
    }
    
}
