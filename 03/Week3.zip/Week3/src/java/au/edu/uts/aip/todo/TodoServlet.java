package au.edu.uts.aip.todo;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

/**
 * A single JSP Model 2 style Servlet that handles requests for our To-do list app.
 * The page command is selected by a parameter named command.
 The command is handled by the Servlet and then the result is rendered by 
 forwarding to a JSP view.
 <p>
 * To use the app, open "http://localhost:8080/Week3/todo" in your web browser.
 * <p>
 * The JSP pages are stored in the /WEB-INF folder.
 * This ensures that the user cannot access the JSP pages directly.
 * <p>
 * Note that in this Servlet, the commands correspond to verbs: "list", "add" and 
 * "create". However, the JSP pages are named as views: "list", "form" and 
 * "added".
 * <p>
 * The Servlet handles both GET and POST requests: both are forwarded to the 
 * same processRequest method.
 */
@WebServlet("/todo")
public class TodoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /**
     * Handles a request according to a supplied parameter named command.
     * Both GET and POST requests are delegated to this single method.
     * Requests are dispatched to a corresponding method in this Servlet.
     * 
     * @param request the HTTP Servlet request
     * @param response the HTTP Servlet response
     * @throws ServletException
     * @throws IOException 
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String command = request.getParameter("command");
        
        if (command == null) {
            response.sendRedirect("todo?command=list");
        } else {
            // Handle the different commands
            switch (command) {
                case "list":
                    listCommand(request, response);
                    
                case "create":
                    createCommand(request, response);
                    break;
                    
                case "add":
                    addCommand(request, response);
                    
                default:
                    response.sendRedirect("todo?command=list");
                    break;
            }
        }
    }
    
    /**
     * Helper function to retrieve the current TaskList bean from the session,
     * creating one if it does not already exist.
     * 
     * @param request the HTTP Servlet request
     * @return a TaskList, either the current one in the session or a new one
     */
    protected TaskList getTaskList(HttpServletRequest request) {
        // Retreive the current TaskList bean from the session,
        // creating it if it does not already exist
        HttpSession session = request.getSession();
        TaskList taskList = (TaskList)session.getAttribute("taskList");
        if (null == taskList) {
            taskList = new TaskList();
            session.setAttribute("taskList", taskList);
        }
        return taskList;
    }
    
    /**
     * Lists all the tasks in the to-do list.
     * Renders the result using the /WEB-INF/list.jsp view.
     * 
     * @param request the HTTP Servlet request
     * @param response the HTTP Servlet response
     * @throws ServletException
     * @throws IOException 
     */
    protected void listCommand(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setAttribute("taskList", getTaskList(request));
        request.getRequestDispatcher("/WEB-INF/list.jsp").forward(request, response);
    }

    /**
     * Initiates the process of creating a new task in the to-do list
     * (i.e., display a form to create a new task).
     * Renders the result using the /WEB-INF/list.jsp view.
     * 
     * @param request the HTTP Servlet request
     * @param response the HTTP Servlet response
     * @throws ServletException
     * @throws IOException 
     */
    protected void createCommand(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/form.jsp").forward(request, response);
    }
    
    /**
     * Adds a task to the to-do list.
     * Renders the result using the /WEB-INF/added.jsp view.
     * 
     * @param request the HTTP Servlet request
     * @param response the HTTP Servlet response
     * @throws ServletException
     * @throws IOException 
     */
    protected void addCommand(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        Task task = new Task();
        task.setTitle(request.getParameter("title"));
        task.setNotes(request.getParameter("notes"));
        task.setTaskList(getTaskList(request));

        request.setAttribute("task", task);
        request.getRequestDispatcher("/WEB-INF/added.jsp").forward(request, response);
    }
}
