package demo.todo;

import java.io.*;

/**
 * A simple model class for a todo list application.
 */
public class Task implements Serializable {

    private String title;
    private String notes;
    
    public Task(String title, String notes) {
        this.title = title;
        this.notes = notes;
    }
    
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

}
