package demo.todo;

import au.edu.uts.aip.mvc.*;
import java.io.*;
import java.util.*;

/**
 * A demo of the simple MVC framework: a todo list application.
 */
public class TodoController extends Controller implements SessionBased, Serializable {
    
    private String title;
    private String notes;
    private ArrayList<Task> tasks = new ArrayList<>();
    
    //--------------------------------------------------------------
    // Action Methods
    
    public String list() {
        return "list.jsp";
    }
    
    public String create() {
        return "create.jsp";
    }
    
    public String add() {
        tasks.add(new Task(title, notes));
        return "add.jsp";
    }
    
    //--------------------------------------------------------------
    // Getters that can be used in the JSP view

    public List<Task> getTasks() {
        return tasks;
    }
    
    public String getTitle() {
        return title;
    }

    public String getNotes() {
        return notes;
    }

    //--------------------------------------------------------------
    // Setters that are automatically set from form submission data
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
}
