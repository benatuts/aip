package demo.greeting;

import au.edu.uts.aip.mvc.*;

/**
 * A demo of the simple MVC framework: a "Hello, World"-style application.
 */
public class GreetingController extends Controller {
    
    private String name;
    
    //--------------------------------------------------------------
    // Action Methods
    
    public String index() {
        return "greet.jsp";
    }
    
    //--------------------------------------------------------------
    // Getters that can be used in the JSP view
    
    public String getTitle() {
        return "This is the title!";
    }
    
    public String getGreeting() {
        if (name == null)
            return "Hello, Stranger";
        else
            return "Hello, " + name;
    }
    
    //--------------------------------------------------------------
    // Setters that are automatically set from form submission data
    
    public void setName(String name) {
        this.name = name;
    }
    
}
