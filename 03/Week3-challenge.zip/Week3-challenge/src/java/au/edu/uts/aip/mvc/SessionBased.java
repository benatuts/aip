package au.edu.uts.aip.mvc;

/**
 * This class is used to indicate that a controller should be created
 * once-per-session, rather than just once per request.
 * Simply implement this interface (i.e., add implements SessionBased to your 
 * controller) to enable the one-per-session mode.
 * <p>
 * I've used an interface here. It is a bit 'old-fashioned' but it is simple to 
 * understand and more backward-compatible. A better way would be to use a 
 * custom annotation -- the code would be almost exactly the same complexity 
 * but it does use newer features of Java. Even better would be to just use
 * Java EE's CDI (Context and Dependency Injection).
 */
public interface SessionBased {
    
}
