package au.edu.uts.aip.mvc;

/**
 * This class is the base class for all Controllers in this simple MVC framework.
 * Even though the class is empty and does nothing, I use this class to help
 * avoid mistakes and security risks. Because you need to extend this class,
 * it is very unlikely that you'd create a controller by accident.
 * @author Benjamin Johnston
 */
public abstract class Controller {
 
}
