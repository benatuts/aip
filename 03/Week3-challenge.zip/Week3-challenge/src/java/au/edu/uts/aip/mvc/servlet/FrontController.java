package au.edu.uts.aip.mvc.servlet;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

/**
 * The FrontController of my simple MVC framework.
 * To use the framework:
 * <ul>
 * <li> Create a Java class that extends Controller.
 * 
 * <li> For each action (i.e., each page URL), create a method that returns a string.
 * 
 * <li> The returned string should be the name of a JSP page stored in WEB-INF.
 * 
 * <li> Any form parameters are automatically set on the controller (if there is a
 *      setter that accepts a String).
 * 
 * <li> From the view (the JSP page) you can use expression language to access any
 *      properties declared as public getters.
 * </ul>
 * The Servlet is mapped to /mvc/* so this means that to call an action method
 * such as pkg.ClassName.actionMethod(), you would open a URL such as
 * /mvc/pkg/ClassName/actionMethod
 */
@WebServlet("/mvc/*")
public class FrontController extends HttpServlet {
    
    /**
     * A cache of actions: saves needing to lookup the action methods from 
     * scratch with every request.
     */
    private ConcurrentHashMap<String,Action> actions = new ConcurrentHashMap<>();
    
    /**
     * This front controller handles POST and GET requests.
     */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        handle(req, resp);
    }

    /**
     * This front controller handles POST and GET requests.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        handle(req, resp);
    }
    
    /**
     * Handle both POST and GET requests.
     * Translates the HTTP request into an action lookup then invokes the action.
     */
    private void handle(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //----------------------------------------------------------------------
        // Get the Action...
        //----------------------------------------------------------------------
                
        Action action = null;
        
        // Get the path (the bit in the URL wildcard)
        String pathInfo = req.getPathInfo().substring(1);
        
        // Have we previously handled this path?
        if (actions.containsKey(pathInfo)) { // Uses a thread-safe ConcurrentHashMap
            // Yes... then use the cached Action
            action = actions.get(pathInfo);  // Uses a thread-safe ConcurrentHashMap
        } else {
            // No... then create an action
            action = Action.fromPath(pathInfo);
            // And cache it for next time
            actions.put(pathInfo, action);   // Uses a thread-safe ConcurrentHashMap
        }
        
        //----------------------------------------------------------------------
        // Get an instance of the controller...
        //----------------------------------------------------------------------
        
        // Do we need to create a new instance of the controller?
        // - "SessionBased" controllers = instance per session
        // - Anything else = instance per request
        Object instance;
        if (action.isSessionBased()) {
            HttpSession session = req.getSession();
            instance = session.getAttribute(action.getSessionKey());
            if (instance == null) {
                instance = action.create();
                session.setAttribute(action.getSessionKey(), instance);
            }
        } else {
            instance = action.create();
        }
        
        //----------------------------------------------------------------------
        // Follow an MVC lifecycle (save form, invoke action, generate view)...
        //----------------------------------------------------------------------
        
        // Call any public setters using the incoming request parameters
        action.callSetters(instance, req.getParameterMap());
        
        // Call the action method
        String view = action.invoke(instance);
        
        // Call any public getters on the controller
        Map<String, Object> attributes = action.callGetters(instance);
        
        // Save the results of the getters back into the request
        // (so that the getters can be accessed directly from the view)
        for (Map.Entry<String, Object> entry :  attributes.entrySet()) {
            req.setAttribute(entry.getKey(), entry.setValue(instance));
        }
        
        // Forward to the JSP view
        req.getRequestDispatcher("/WEB-INF/" + view).forward(req, resp);
    }   
}
