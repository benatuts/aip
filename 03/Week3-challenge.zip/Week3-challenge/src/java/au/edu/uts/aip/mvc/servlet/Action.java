package au.edu.uts.aip.mvc.servlet;

import au.edu.uts.aip.mvc.Controller;
import au.edu.uts.aip.mvc.SessionBased;
import java.lang.reflect.*;
import java.util.*;

/**
 * This class contains meta-data about an Action method. An action method
 * is a method on a controller. It has no parameters and returns a String.
 * When a web page is requested, the corresponding action method is called.
 * <p>
 * This class is responsible for invoking the action method and calling 
 * setters and getters.
 */
public class Action {

    /**
     * Create an action from a "URL-friendly" path.
     * In an URL, actions are referred with paths such as: pkg1/pkg2/ClassName/method.
     * These paths are translated to action methods such as: pkg1.pkg2.ClassName.method().
     * <p>
     * @param path the URL-friendly path to translate
     * @return an action corresponding to the supplied path or null if any error occurred
     */
    public static Action fromPath(String path) {
        // Remove anything after a dot
        if (path.contains("."))
            path = path.substring(0, path.lastIndexOf("."));
        
        // Split into class name and method name
        int methodIndex = path.lastIndexOf("/");
        String className = path.substring(0, methodIndex).replace("/", ".");
        String methodName = path.substring(methodIndex + 1);
        
        try {
            // Does the class exist?
            Class clazz = Class.forName(className); // can throw exception
            
            // Is it public and concrete?
            int modifiers = clazz.getModifiers();
            if (Modifier.isAbstract(modifiers) || 
                Modifier.isInterface(modifiers) || 
                !Modifier.isPublic(modifiers) )
                return null;
            
            // Is it the right type?
            if (!Controller.class.isAssignableFrom(clazz))
                return null;
                
            // Does it have a public, no-arg constructor?
            Constructor constructor = clazz.getConstructor();
            if (!Modifier.isPublic(constructor.getModifiers()))
                return null;
            
            // Does the action method exist?
            Method method = clazz.getMethod(methodName); // can throw exception
            
            // Is it public, non-static
            modifiers = method.getModifiers();
            if (!Modifier.isPublic(modifiers) ||
                Modifier.isStatic(modifiers))
                return null;
            
            // Does it return a view name (a String)?
            Class returnType = method.getReturnType();
            if (!String.class.equals(returnType))
                return null;
            
            // Ok - it looks good!
            return new Action(method);
            
        } catch (ClassNotFoundException | NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
            return null;
        }
        
    }
    
    private Class controllerClass;
    private Method actionMethod;
    
    /**
     * All setters that take one String argument and returns void
     */
    private HashMap<String,Method> setters;
    
    /**
     * All getters that take no arguments (the property names are lowercased)
     */
    private HashMap<String,Method> getters;
    
    /**
     * The name used to store instances of the controller in the current session.
     */
    private String sessionKey;
    
    /**
     * Create a new Action: an action is a method on a class that extends 
     * Controller.
     * <p>
     * The controller class must be public, concrete and have a public no-arg 
     * constructor. The action method must be public, non-static, have no 
     * arguments, and return a String.
     * 
     * @param actionMethod an action method on a controller
     */
    public Action(Method actionMethod) {
        this.controllerClass = actionMethod.getDeclaringClass();
        this.actionMethod = actionMethod;
        
        // A unique name for storing instances of the controller
        // Two action methods for the same controller should use the same sesison key
        sessionKey = "MVC:" + controllerClass.getCanonicalName();
        
        setters = new HashMap<>();
        getters = new HashMap<>();
        
        // Search through the declared methods of the controller to find setters and getters
        for (Method method : controllerClass.getDeclaredMethods()) {
        
            int modifiers = method.getModifiers();
            
            // Is it non-static and public
            if (Modifier.isStatic(modifiers) ||
                !Modifier.isPublic(modifiers))
                continue;
            
            // Are we looking at a getter?
            if (method.getName().startsWith("get")) {
                
                // Does it have zero parameters?
                if (method.getParameterCount() != 0)
                    continue;
                
                String name = method.getName().substring(3).toLowerCase();
                getters.put(name, method);
                
            // Are we looking at a setter ?
            } else if (method.getName().startsWith("set")) {
            
                // Does it have one parameter?
                if (method.getParameterCount() != 1)
                    continue;
                
                // Is the parameter a String?
                if (!String.class.equals(method.getParameterTypes()[0]))
                    continue;
                    
                // Does it return void?
                if (!Void.TYPE.equals(method.getReturnType()))
                    continue;
                
                String name = method.getName().substring(3).toLowerCase();
                setters.put(name, method);
            }
        }
        
    }
    
    /**
     * Returns true if controller instances should be reused in a session.
     * This is the case if the controller of the action implements SessionBased.
     * @return true if the controller implements SessionBased
     */
    public boolean isSessionBased() {
        return SessionBased.class.isAssignableFrom(controllerClass);
    }
    
    /**
     * Get the unique key to store instances of the controller in the session.
     * @return an identifier unique to the controller class
     */
    public String getSessionKey() {
        return sessionKey;
    }
    
    /**
     * Create a new instance of the controller associated with this action.
     * @return a new instance of the underlying class of the action method
     */
    public Object create() {
        try {
            return controllerClass.newInstance();
        } catch (InstantiationException | IllegalAccessException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Invoke the action method on an instance of the controller.
     * @param instance the instance of the controller to use
     * @return the view to render (the result of the action method)
     */
    public String invoke(Object instance) {
        try {
            return (String)actionMethod.invoke(instance);
        } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Call all the declared getters on the controller.
     * <p>
     * Here, a getter is a public instance method, with no arguments and whose 
     * name starts with "get". Note that, contrary to the JavaBeans 
     * specification, the entire property name is lowercased (rather than just 
     * the first character).
     * @param instance the instance of the controller to invoke the getters
     * @return a map containing the lowercased property name and the value
     */
    public Map<String, Object> callGetters(Object instance) {
        HashMap<String, Object> result = new HashMap<>();
        
        for (Map.Entry<String, Method> getter : getters.entrySet()) {
            try {
                Object outcome = getter.getValue().invoke(instance);
                result.put(getter.getKey(), outcome);
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                // Ignore any errors
            }
        }
        return result;
    }
    
    /**
     * Use the supplied parameter map to call any setters.
     * A setter will only be called where there is exactly one element in the 
     * value of the String[] of the parameterMap.
     * <p>
     * Here, a setter is a public instance method, with only one String 
     * argument, that returns void and whose name starts with "set". Note that, 
     * contrary to the JavaBeans specification, the entire property name is 
     * lowercased (rather than just the first character).
     * @param instance
     * @param parameterMap 
     */
    public void callSetters(Object instance, Map<String, String[]> parameterMap) {
        for (Map.Entry<String, Method> setter : setters.entrySet()) {
            if (parameterMap.containsKey(setter.getKey())) {
                String[] values = parameterMap.get(setter.getKey());
                
                // Check there is exactly one value for the parameter
                if (values == null || values.length != 1)
                    continue;
                
                try {
                    // Call the setter
                    setter.getValue().invoke(instance, values[0]);
                } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException ex) {
                    // Ignore any errors
                }
            }
        }
    }
    
}
