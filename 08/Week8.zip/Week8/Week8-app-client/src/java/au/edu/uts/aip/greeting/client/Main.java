package au.edu.uts.aip.greeting.client;

import au.edu.uts.aip.greeting.domain.*;
import javax.ejb.*;
import javax.naming.*;

/**
 * A simple Java EE application client to test remote interfaces to session beans.
 */
public class Main {
    
    @EJB
    private static GreetingRemote injectedGreeting;
    
    @EJB
    private static StatefulGreetingRemote statefulGreeting;
    
    @EJB
    private static DTOGreetingRemote dtoGreeting;

    /**
     * Main method: generates a greeting using each of the stateless, stateful
     * and stateful-with-DTO session beans.
     * @param args
     * @throws Exception 
     */
    public static void main(String[] args) throws Exception {
        System.out.println("Starting Week8 Client");
        GreetingRemote jndiGreeting = InitialContext.doLookup("java:app/Week8-ejb/GreetingBean!au.edu.uts.aip.greeting.domain.GreetingRemote");
        System.out.println("JNDI lookup greeting: " + jndiGreeting.getGreeting());
        
        System.out.println("Injected greeting: " + injectedGreeting.getGreeting());
        
        statefulGreeting.setName("Mike");
        System.out.println("Injected stateful greeting: " + statefulGreeting.getGreeting());
        statefulGreeting.close();
        
        PersonName name = new PersonName();
        name.setFirstName("Carol");
        name.setLastName("Brady");
        dtoGreeting.setName(name);
        System.out.println("Injected DTO greeting: " + dtoGreeting.getGreeting());
        dtoGreeting.close();
    }
   
}