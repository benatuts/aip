package au.edu.uts.aip.greeting.web;

import au.edu.uts.aip.greeting.domain.*;
import javax.ejb.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A backing bean to test the stateless session bean.
 */
@Named
@RequestScoped
public class GreetingController {

    @EJB
    private GreetingBean greeting;
   
    /**
     * Uses the stateless EJB to generate a greeting.
     * @return the customized greeting
     */
    public String getGreeting() {
        return greeting.getGreeting();
    }
   
    /**
     * Gets the unique ID of the underlying EJB.
     * @return a unique identifier
     */
    public int getUniqueId() {
        return greeting.getUniqueId();
    }
   
}