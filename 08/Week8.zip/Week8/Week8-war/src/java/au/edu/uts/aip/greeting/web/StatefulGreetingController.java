package au.edu.uts.aip.greeting.web;

import au.edu.uts.aip.greeting.domain.*;
import javax.ejb.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A backing bean to test the stateful session bean.
 */
@Named
@RequestScoped
public class StatefulGreetingController {

    private String name;
    
    @EJB
    private StatefulGreetingBean greeting;
   
    public void setName(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    /**
     * Uses the stateful EJB to generate a greeting from the name.
     * @return the customized greeting
     */
    public String getGreeting() {
        greeting.setName(name);
        return greeting.getGreeting();
    }
   
    /**
     * Gets the unique ID of the underlying EJB.
     * @return a unique identifier
     */
    public int getUniqueId() {
        return greeting.getUniqueId();
    }
   
}