package au.edu.uts.aip.greeting.web;

import au.edu.uts.aip.greeting.domain.*;
import javax.ejb.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A backing bean to test the DTO-based stateful session bean.
 */
@Named("dtoGreetingController") // Override the default name
@RequestScoped
public class DTOGreetingController {

    private PersonName name = new PersonName();
    
    @EJB
    private DTOGreetingBean greeting;
   
    public void setName(PersonName name) {
        this.name = name;
    }
    
    public PersonName getName() {
        return name;
    }
    
    /**
     * Uses the stateful EJB to generate a greeting from the PersonName.
     * @return the customized greeting
     */
    public String getGreeting() {
        if (name != null && null != name.getFirstName() && null != name.getLastName()) {
            greeting.setName(name);
        }
        return greeting.getGreeting();
    }
   
    /**
     * Gets the unique ID of the underlying EJB.
     * @return a unique identifier
     */
    public int getUniqueId() {
        return greeting.getUniqueId();
    }
   
}