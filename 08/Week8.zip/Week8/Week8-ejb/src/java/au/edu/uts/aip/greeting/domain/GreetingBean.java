package au.edu.uts.aip.greeting.domain;

import javax.ejb.*;

/**
 * A stateless session bean that generates a greeting.
 * This bean has two interfaces: the @LocalBean no-interface view and a 
 * remote interface.
 */
@Stateless
@LocalBean
public class GreetingBean implements GreetingRemote {

    private int uniqueId = UniqueIdGenerator.generate();
   
    /**
     * Generate a unique id. This method is used to understand the EJB lifecycle.
     * @return a unique identifier
     */
    @Override
    public int getUniqueId() {
        return uniqueId;
    }
   
    /**
     * Generates a generic (stateless) greeting.
     * @return the greeting
     */
    @Override
    public String getGreeting() {
        
        // Uncomment the following code to slow down this method.
        /*
        try {
            Thread.sleep(5000); // wait for 5000 milliseconds (i.e., 5 seconds)
        } catch (InterruptedException ie) {
            // do nothing
        }
        */
        
        return "Hello, World!";
    }

}