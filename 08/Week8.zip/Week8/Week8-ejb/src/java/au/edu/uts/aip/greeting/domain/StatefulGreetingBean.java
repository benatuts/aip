package au.edu.uts.aip.greeting.domain;

import javax.ejb.*;

/**
 * A stateful session bean that generates a greeting.
 * This bean has two interfaces: the @LocalBean no-interface view and a 
 * remote interface.
 */
@Stateful
@LocalBean
public class StatefulGreetingBean implements StatefulGreetingRemote {

    private int uniqueId = UniqueIdGenerator.generate();
    private String name;
    
    /**
     * Generate a unique id. This method is used to understand the EJB lifecycle.
     * @return a unique identifier
     */
    @Override
    public int getUniqueId() {
        return uniqueId;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Generates a customized greeting.
     * @return the greeting
     */
    @Override
    public String getGreeting() {
        if (name != null) {
            return "Hello, " + name + "!";
        } else {
            return "Hello, World!";
        }
    }

    /**
     * Closes the EJB, so that it may be destroyed and garbage collected.
     */
    @Override
    @Remove
    public void close() {
        // do nothing - no resources need to be closed
    }

}