package au.edu.uts.aip.greeting.domain;

/**
 * A utility that generates unique integers.
 */
public class UniqueIdGenerator {

    private static int counter = 0;

    /**
     * Generates a unique integer each time it is called.
     * This method is thread safe (it can be used concurrently without risk of
     * data corruption).
     */
    public static synchronized int generate() {
        counter++;
        return counter;
    }
    
}
