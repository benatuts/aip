package au.edu.uts.aip.greeting.domain;

import javax.ejb.*;

/**
 * A stateful session bean that generates a greeting based on data transferred 
 * by a Data transfer Object.
 */
@Stateful
@LocalBean
public class DTOGreetingBean implements DTOGreetingRemote {

    private int uniqueId = UniqueIdGenerator.generate();
    private PersonName name;
    
    /**
     * Generate a unique id. This method is used to understand the EJB lifecycle.
     * @return a unique identifier
     */
    @Override
    public int getUniqueId() {
        return uniqueId;
    }

    /**
     * Sets the name of the person to be greeted.
     * @param name the name of the person
     */
    @Override
    public void setName(PersonName name) {
        this.name = name;
    }
    
    /**
     * Generates a customized greeting.
     * @return the greeting
     */
    @Override
    public String getGreeting() {
        if (name != null) {
            return "Hello, " + name.getFirstName() + " " + name.getLastName() + "!";
        } else {
            return "Hello, World!";
        }
    }

    /**
     * Closes the EJB, so that it may be destroyed and garbage collected.
     */
    @Override
    @Remove
    public void close() {
        // do nothing - no resources need to be closed
    }

}