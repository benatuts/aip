package au.edu.uts.aip.greeting.domain;

import java.io.*;

/**
 * A data transfer object used to send a first-name/last-name pair to the 
 * greeting EJB.
 */
public class PersonName implements Serializable {
    
    private String firstName;
    private String lastName;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
}
