package au.edu.uts.aip.greeting.domain;

import javax.ejb.*;

/**
 * A remote interface used by remote clients of the GreetingBean EJB.
 */
@Remote
public interface GreetingRemote {
   
    /**
     * Generate a greeting.
     * @return a greeting
     */
    public String getGreeting();
    
    /**
     * Generate an identifier to uniquely identify each instance of the EJB
     * @return a unique identifier
     */
    public int getUniqueId();
   
}