package au.edu.uts.aip.greeting.domain;

import javax.ejb.*;

/**
 * A remote interface used by remote clients of the StatefulGreetingBean EJB.
 */
@Remote
public interface StatefulGreetingRemote {
   
    /**
     * Sets the name to use for generating a customized greeting.
     * @param name 
     */
    public void setName(String name);
    
    /**
     * Generate a customized greeting based on the set name.
     * If no name has been set, defaults to a generic greeting.
     * @return a greeting
     */
    public String getGreeting();
    
    /**
     * Generate an identifier to uniquely identify each instance of the EJB
     * @return a unique identifier
     */
    public int getUniqueId();
    
    @Remove
    public void close();
   
}