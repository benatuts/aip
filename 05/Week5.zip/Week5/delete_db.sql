drop view jdbcrealm_user;
drop view jdbcrealm_group;
drop table account;
