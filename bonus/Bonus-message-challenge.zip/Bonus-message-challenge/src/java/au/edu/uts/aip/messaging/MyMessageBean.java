package au.edu.uts.aip.messaging;

import java.util.*;
import javax.ejb.*;
import javax.jms.*;

/**
 * This message driven bean logs incoming messages to the server log.
 * It displays a message showing:
 *   the current time, 
 *   a unique id to identify the message driven bean, 
 *   a counter for the number of messages that this instance has handled, 
 *   and finally the text of the message itself.
 * <p>
 * The output of this bean demonstrates that:
 *   the application server creates many instances to handle requests,
 *   there is a limit to the number of instances running at once,
 *   instances are reused to handle many requests.
 */
@MessageDriven(mappedName = "jms/aip")
public class MyMessageBean implements MessageListener {
   
    /**
     * A counter to uniquely identify instances of this message driven bean.
     */
    private static int idGenerator;
    
    /**
     * The unique number identifying this instance of the message driven bean.
     */
    private int id;
    
    /**
     * A count of the number of messages that this particular instance has
     * handled.
     */
    private int beanMessageCounter;
    
    /**
     * Create a new instance while initializing the bean's unique id.
     */
    public MyMessageBean() {
        synchronized (MyMessageBean.class) {
            id = idGenerator++;
        }
    }
    
    /**
     * Handles messages that have been queued by the application server.
     * @param message the message sent from the client
     */
    @Override
    public void onMessage(Message message) {
        try {
            // Slow this bean down
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            // this exception should never occur
        }
        
        try {
            // Extract the message text
            String text = message.getBody(String.class);
            
            // Add one to the message count
            beanMessageCounter++;
            
            // Create a log message
            String log = "At " + new Date().toString() + " MyMessageBean with id " + id + " received its message #" + beanMessageCounter + ": " + text;
            
            // Output the message to the server log
            System.out.println(log);
            
        } catch (JMSException ex) {
            ex.printStackTrace();
        }
    }
    
}
