package au.edu.uts.aip.messaging;

import java.util.*;
import javax.annotation.*;
import javax.enterprise.context.*;
import javax.inject.*;
import javax.jms.*;
import javax.jms.Queue;

/**
 * This is a backing bean for testing message driven beans.
 * It has one main function: send a user-supplied string to a JMS queue, 100
 * times. The application server processes those messages slowly: each takes
 * five seconds. However, the message sending process is nearly instantaneous.
 * The backing bean times the message sending process to demonstrate this.
 */
@Named
@RequestScoped
public class MyMessageController {
    
    /**
     * This is used to obtain connections to a JMS provider
     */
    @Resource
    private ConnectionFactory factory;
    
    /**
     * This is a message queue that the JMS provider gives access to.
     */
    @Resource(lookup="jms/aip")
    private Queue queue;
    
    /**
     * User-supplied and user-editable text that will be included in the message.
     */
    private String text;

    /**
     * This variable stores the start time of an operation. Combined, with the
     * end time, this is used to display to the user the time that the server
     * used to perform an operation.
     */
    private long start;
    
    /**
     * The end time of an operation.
     */
    private long end;
    
    //--------------------------------------------------------------------------
    // Timer Information
    
    public double getDuration() {
        return (end - start) / 1000.0;
    }
    
    public boolean hasDuration() {
        return start != 0 && end != 0;
    }
    
    private void startTimer() {
        start = System.currentTimeMillis();
    }
    
    private void endTimer() {
        end = System.currentTimeMillis();
    }
    
    //--------------------------------------------------------------------------
    // User Interface properties and action methods
    
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    
    /**
     * Use JMS to send 100 messages containing the user-supplied text as well
     * as a message count and the time of sending.
     * @throws JMSException
     */
    public void sendHundredMessages() throws JMSException {
        startTimer();
        try (Connection connection = factory.createConnection()) {
            // Create a producer that can be used to send messages
            Session session = connection.createSession();
            MessageProducer producer = session.createProducer(queue);
            
            // Send as a text message: it is also possible to send binary messages
            // as well as object messages
            TextMessage message = session.createTextMessage();
            for (int i=1; i<=100; i++) {
                // Configure the message
                String body = text + " (#" + i + ", sent " + new Date().toString() + ")";
                message.setText(body);
                
                // Send the message
                producer.send(message);
            }
        }
        endTimer();
    }
    
}
