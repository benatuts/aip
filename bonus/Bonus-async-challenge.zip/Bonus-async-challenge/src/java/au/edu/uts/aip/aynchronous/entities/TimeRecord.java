package au.edu.uts.aip.aynchronous.entities;

import java.io.*;
import java.util.*;
import javax.persistence.*;

/**
 * A simple entity to keep track of operations performed in this challenge problem.
 * Associates a message (the operation) with a timestamp.
 */
@Entity
@NamedQuery(name = "TimeRecord.findAll", query = "select tr from TimeRecord tr order by tr.creationTime asc")
public class TimeRecord implements Serializable {

    /**
     * A unique ID.
     */
    @Id
    @GeneratedValue
    private int id;
    
    /**
     * The timestamp indicating that the moment that the entity was created.
     */
    @Temporal(TemporalType.TIMESTAMP)
    private Date creationTime;
    
    /**
     * A plain-English description of the operation that the user performed that 
     * resulted in this record being created.
     */
    private String operation;
    
    /**
     * Create an empty TimeRecord.
     */
    public TimeRecord() {
        // default constructor
    }
    
    /**
     * Create a time record with a supplied description and with a creation time
     * set to the current moment in time.
     * @param operation a plain-English description of the end-user operation associated with creating this entity
     */
    public TimeRecord(String operation) {
        this.operation = operation;
        creationTime = new Date();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }
    
}
