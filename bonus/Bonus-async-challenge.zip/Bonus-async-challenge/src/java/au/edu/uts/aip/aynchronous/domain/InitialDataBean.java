package au.edu.uts.aip.aynchronous.domain;

import au.edu.uts.aip.aynchronous.entities.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;

/**
 * This Singleton Startup bean ensures that there is at least one TimeRecord
 * entity in the database. On each deployment, a new "Application Deployed"
 * record is added.
 */
@Singleton
@Startup
public class InitialDataBean {
    
    @PersistenceContext
    private EntityManager em;
    
    /**
     * Populate the database with the initial data.
     */
    @PostConstruct
    public void init() {
        em.persist(new TimeRecord("Application Started/Deployed"));
    }
    
}
