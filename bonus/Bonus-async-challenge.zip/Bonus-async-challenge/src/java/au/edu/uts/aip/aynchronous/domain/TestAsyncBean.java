package au.edu.uts.aip.aynchronous.domain;

import au.edu.uts.aip.aynchronous.entities.*;
import java.util.*;
import java.util.concurrent.*;
import javax.ejb.*;

/**
 * Higher level business functions that demonstrate some differences between
 * asynchronous and synchronous programming in Java EE.
 */
@Stateless
public class TestAsyncBean {

    /**
     * The TimeRecordBean performs low-level operations that are used by this
     * EJB.
     */
    @EJB
    private TimeRecordBean timeRecordBean;
    
    /**
     * Retrieve all TimeRecord entities in the database, ordered by time.
     * @return a list of TimeRecord entities in the database
     */
    public List<TimeRecord> getTimeRecords() {
        return timeRecordBean.findAll();
    }
    
    /**
     * Delete all TimeRecord entities from the database.
     */
    public void deleteAll() {
        timeRecordBean.deleteAll();
    }
    
    /**
     * Create a single TimeRecord immediately.
     * @param operation a description of the operation to be stored in the TimeRecord
     * @return the newly created TimeRecord
     */
    public TimeRecord createOneNow(String operation) {
        return timeRecordBean.createOneNow(operation);
    }

    /**
     * Create four TimeRecords slowly, one-by-one, synchronously.
     * If each takes 2 seconds, this should run in 8 seconds.
     * @param operation a description of the operation to be stored in the TimeRecords
     * @return a list of newly created TimeRecords
     */
    public List<TimeRecord> createFourSynchronous(String operation) {
        TimeRecord one = timeRecordBean.createOneSlowly(operation);
        TimeRecord two = timeRecordBean.createOneSlowly(operation);
        TimeRecord three = timeRecordBean.createOneSlowly(operation);
        TimeRecord four = timeRecordBean.createOneSlowly(operation);
        return Arrays.asList(one, two, three, four);
    }

    /**
     * Create four TimeRecords slowly but simultaneously.
     * If each takes 2 seconds, this should also run in just 2 seconds.
     * @param operation a description of the operation to be stored in the TimeRecords
     * @return a list of newly created TimeRecords
     */
    public List<TimeRecord> createFourAsynchronousWait(String operation) {
        try {
            
            Future<TimeRecord> futureOne = timeRecordBean.createOneSlowlyAsynchronously(operation);
            Future<TimeRecord> futureTwo = timeRecordBean.createOneSlowlyAsynchronously(operation);
            Future<TimeRecord> futureThree = timeRecordBean.createOneSlowlyAsynchronously(operation);
            Future<TimeRecord> futureFour = timeRecordBean.createOneSlowlyAsynchronously(operation);

            TimeRecord one = futureOne.get();
            TimeRecord two = futureTwo.get();
            TimeRecord three = futureThree.get();
            TimeRecord four = futureFour.get();

            return Arrays.asList(one, two, three, four);
            
        } catch (InterruptedException | ExecutionException e) {
            // This should not occur
            throw new EJBException(e);
        }
    }
    
    /**
     * Create four TimeRecords slowly, one-by-one but asynchronously.
     * If each takes 2 seconds, this should run in 8 seconds. However, it will
     * return control to the caller immediately, with a Future -- a promise to
     * return the list of TimeRecords that have been created.
     * @param operation a description of the operation to be stored in the TimeRecords
     * @return a promise to return a list of newly created TimeRecords
     */
    @Asynchronous
    public Future<List<TimeRecord>> createFourAsynchronousFuture(String operation) {
        TimeRecord one = timeRecordBean.createOneSlowly(operation);
        TimeRecord two = timeRecordBean.createOneSlowly(operation);
        TimeRecord three = timeRecordBean.createOneSlowly(operation);
        TimeRecord four = timeRecordBean.createOneSlowly(operation);

        return new AsyncResult<>(Arrays.asList(one, two, three, four));
    }
    
}
