package au.edu.uts.aip.aynchronous.domain;

import au.edu.uts.aip.aynchronous.entities.*;
import java.util.*;
import java.util.concurrent.*;
import javax.ejb.*;
import javax.persistence.*;

/**
 * This EJB provides the low level operations for creating and deleting 
 * TimeRecord entities. It provides synchronous and asynchronous methods.
 * This class is not used directly by the user interface, instead it is accessed
 * via the TestAsyncBean that provides higher-level functionality.
 */
@Stateless
public class TimeRecordBean {
    
    @PersistenceContext
    private EntityManager em;
    
    /**
     * Retrieve all TimeRecord entities in the database, ordered by time.
     * @return a list of TimeRecord entities in the database
     */
    public List<TimeRecord> findAll() {
        TypedQuery<TimeRecord> query = em.createNamedQuery("TimeRecord.findAll", TimeRecord.class);
        return query.getResultList();
    }
    
    /**
     * A helper utility to sleep for a given duration, ignoring any interrupted
     * exceptions that may occur.
     * @param milliseconds the time to sleep for, in milliseconds
     */
    private void sleep(long milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException ex) {
            // do nothing
        }
    }
    
    /**
     * Create a single TimeRecord immediately.
     * @param operation a description of the operation to be stored in the TimeRecord
     * @return the newly created TimeRecord
     */
    public TimeRecord createOneNow(String operation) {
        TimeRecord result = new TimeRecord(operation);
        em.persist(result);
        return result;
    }
    
    /**
     * Create a single TimeRecord slowly.
     * Persists the entity after a 2 second delay.
     * @param operation a description of the operation to be stored in the TimeRecord
     * @return the newly created TimeRecord
     */
    public TimeRecord createOneSlowly(String operation) {
        sleep(2000);
        return createOneNow(operation);
    }
    
    /**
     * Create a single TimeRecord slowly, but asynchronously.
     * Persists the entity after a 2 second delay.
     * @param operation a description of the operation to be stored in the TimeRecord
     * @return a promise for the newly created TimeRecord
     */
    @Asynchronous
    public Future<TimeRecord> createOneSlowlyAsynchronously(String operation) {
        sleep(2000);
        TimeRecord result = createOneNow(operation);
        return new AsyncResult<>(result);
    }

    /**
     * Delete all TimeRecord entities from the database.
     */
    public void deleteAll() {
        for (TimeRecord record : findAll())
            em.remove(record);
    }
    
}
