package au.edu.uts.aip.aynchronous.web;

import au.edu.uts.aip.aynchronous.domain.*;
import au.edu.uts.aip.aynchronous.entities.*;
import java.util.*;
import javax.ejb.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * This is the Backing Bean for various tests of the @Asynchronous annotation
 * @author Benjamin
 */
@Named
@RequestScoped
public class TestAsyncController {
    
    /**
     * The domain logic is in this EJB
     */
    @EJB
    private TestAsyncBean testAsyncBean;
    
    /**
     * This variable stores the start time of an operation. Combined, with the
     * end time, this is used to display to the user the time that the server
     * used to perform an operation.
     */
    private long start;
    
    /**
     * The end time of an operation.
     */
    private long end;
    
    //--------------------------------------------------------------------------
    // Timer Information
    
    public double getDuration() {
        return (end - start) / 1000.0;
    }
    
    public boolean hasDuration() {
        return start != 0 && end != 0;
    }
    
    private void startTimer() {
        start = System.currentTimeMillis();
    }
    
    private void endTimer() {
        end = System.currentTimeMillis();
    }
    
    //--------------------------------------------------------------------------
    // Core demo functionality
    
    /**
     * Retrieve a list of TimeRecord entities stored in the database.
     * Every operation in this project results in a record stored in the database.
     * @return a list of TimeRecords in the database
     */
    public List<TimeRecord> getTimeRecords() {
        return testAsyncBean.getTimeRecords();
    }
    
    /**
     * Creates four TimeRecord entities synchronously one-by-one.
     * If each takes 2 seconds, then in total this should take 8 seconds.
     */
    public void createFourSynchronous() {
        startTimer();
        testAsyncBean.createFourSynchronous("Create Four Synchronously");
        endTimer();
    }
    
    /**
     * Create four TimeRecords asynchronously, but wait for their completion.
     * If each takes 2 seconds, then in total this should only take 2 seconds.
     */
    public void createFourAsynchronousWait() {
        startTimer();
        testAsyncBean.createFourAsynchronousWait("Create Four Simultaneously");
        endTimer();
    }
    
    /**
     * Create four TimeRecords one-by-one, but run it asynchronously and do not 
     * wait for their completion.
     * Control will return to the user immediately, but it will take 8 seconds
     * for the records to be added to the database.
     */
    public void createFourAsynchronousFuture() {
        startTimer();
        testAsyncBean.createFourAsynchronousFuture("Create Four One-by-One Asynchronously");
        endTimer();
    }
    
    /**
     * Refreshes the screen: adds an extra record to the database and then
     * shows an updated table.
     */
    public void refreshClicked() {
        startTimer();
        testAsyncBean.createOneNow("Refresh Clicked");
        endTimer();
    }
    
    /**
     * Erase all TimeRecords from the database. This may be run by the user when
     * he/she wants to clean up the table.
     */
    public void clearDatabase() {
        startTimer();
        testAsyncBean.deleteAll();
        endTimer();
    }
    
}
