package au.edu.uts.aip.transactions.domain;

import java.sql.*;
import javax.annotation.*;
import javax.ejb.*;
import javax.sql.*;

@Stateless
public class TransactionIsolationBean {
    
    @Resource(lookup="jdbc/aip")
    private DataSource ds;
    
    /**
     * Uses JDBC to read the current value from the integer_store table.
     * @return the current value of the integer_store
     * @throws SQLException 
     */
    private int read() throws SQLException {
        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(
                "select val from integer_store where id = 1")) {
            
            if (rs.next()) {
                return rs.getInt(1);
            } else {
                throw new RuntimeException("No data in table named integer_store");
            }
        }
    }
    
    /**
     * Uses JDBC to update the current value in the integer_store table.
     * @param value the value to store in the database
     * @throws SQLException 
     */
    private void write(int value) throws SQLException {
        try (Connection conn = ds.getConnection();
             PreparedStatement stmt = conn.prepareStatement(
                    "update integer_store set val = ? where id = 1")) {
            
            stmt.setInt(1, value);
        
            int changes = stmt.executeUpdate();
            
            if (changes != 1) {
                throw new RuntimeException("Incorrect number of rows changed when updating");
            }
        }
    }

    /**
     * Set the initial value of the integer_store to be 0.
     */
    public void init() {
        try {
            int value = 0;
            System.out.println("Setting initial value " + value);
            write(value);
        } catch (SQLException sqle) {
            System.out.println("Initialization exception: " + sqle.getMessage());
        }
    }
    
    /**
     * Asynchronously (i.e., concurrently) attempt to perform read/write operations each
     * 500 milliseconds. Reports the progress to the system log.
     * <p>
     * A call such as run("A", "rr w", 1) has the following effect:
     * <ul>
     * <li>
     *   The first parameter is a prefix used in log files.
     * <li>
     *   The "rr w" is the list of operations. Each character represents an operation.
     *   "r" represents a read, "w" represents a write and any other letter does nothing.
     *   The sequence of operations is performed one after the other, pausing 500 milliseconds
     *   between each.
     * <li>
     *   The third parameter means that any write operation will write the number 1.
     * </ul>
     * So, this call would have the following effect:
     * <ul>
     * <li>Wait 500ms, then read the current value in the database
     * <li>Wait 500ms, then read the current value in the database
     * <li>Wait 500ms
     * <li>Wait 500ms, then write the number 1 to the database
     * </ul>
     * If any read/write operation blocks, then the method will block. The method will 
     * not try to "catch" up with lost time by avoiding the waiting.
     * @param prefix the prefix to use in the system log
     * @param operations a sequence of read/write commands to use
     * @param writeValue the value to use in any write operation
     */
    @Asynchronous
    public void run(String prefix, String operations, int writeValue) {
        try {
            long start = System.currentTimeMillis();
            int counter = 0;
            for (char c : operations.toCharArray()) {
                counter++;
                Thread.sleep(500); // pause half a second between actions
                switch (c) {
                    case 'r':
                    case 'R':
                        // Read --------------------------------
                        int readValue = read();
                        System.out.println(prefix + "(" + counter + "): read value " + readValue);
                        break;
                    case 'w':
                    case 'W':
                        // Write -------------------------------
                        write(writeValue);
                        System.out.println(prefix + "(" + counter + "): written value " + writeValue);
                        break;
                }
            }
            // Calculate the total time used to do the transaction
            long duration = System.currentTimeMillis() - start;
            System.out.println(prefix + "(" + counter + "): committing, total clock time is " + duration + "ms");
            
        } catch (SQLException | InterruptedException e) {
            System.out.println(prefix + ": exception " + e.getMessage());
        }
    }
    
}
