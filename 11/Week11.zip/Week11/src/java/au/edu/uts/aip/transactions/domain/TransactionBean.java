package au.edu.uts.aip.transactions.domain;

import javax.ejb.*;

/**
 * Tests various aspects of the transaction lifecycle and transaction isolation.
 */
@Stateless
public class TransactionBean {

    @EJB
    private SecondaryBean secondaryBean;
    
    @EJB
    private TransactionIsolationBean transactionIsolationBean;
    
    /**
     * Calls a method with a NEVER transaction attribute, from a context with 
     * a transaction (REQUIRED). REQUIRED means that the method is always run 
     * with a transaction. If no existing transaction is available then the 
     * container will begin a new transaction automatically.
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void requiredThenNever() {
        secondaryBean.never();
    }
    
    /**
     * Calls a method with a MANDATORY transaction attribute, from a context
     * with no transaction (NOT_SUPPORTED). NOT_SUPPORTED means that the method 
     * is run without a transaction: any existing transaction is suspended.
     */
    @TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
    public void notSupportedThenMandatory() {
        secondaryBean.mandatory();
    }
    
    /**
     * Run five separate transactions that each perform different sequences of
     * read/write operations. This will output data to the GlassFish logs that 
     * may be helpful for understanding the effects of transaction isolation.
     */
    public void isolationTest() {
        transactionIsolationBean.init();
        transactionIsolationBean.run("A", " wr r",      1);
        transactionIsolationBean.run("B", "    rw",     2);
        transactionIsolationBean.run("C", "    r r w",  3);
        transactionIsolationBean.run("D", "   wr rw",   4);
        transactionIsolationBean.run("E", "r r r r  r", 5);
    }
    
}
