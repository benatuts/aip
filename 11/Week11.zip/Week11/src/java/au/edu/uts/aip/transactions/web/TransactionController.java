package au.edu.uts.aip.transactions.web;

import au.edu.uts.aip.transactions.domain.*;
import javax.ejb.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A simple backing bean that passes any actions to the corresponding methods in 
 * the underlying Enterprise JavaBean (named TransactionBean).
 */
@Named
@RequestScoped
public class TransactionController {
    
    @EJB
    private TransactionBean transactionBean;
    
    public void requiredThenNever() {
        transactionBean.requiredThenNever();
    }
    
    public void notSupportedThenMandatory() {
        transactionBean.notSupportedThenMandatory();
    }
    
    public void isolationTest() {
        transactionBean.isolationTest();
    }
    
}
