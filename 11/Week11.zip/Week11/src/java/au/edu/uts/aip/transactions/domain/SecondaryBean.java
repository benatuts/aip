package au.edu.uts.aip.transactions.domain;

import javax.ejb.*;

/**
 * A helper bean to test transaction attributes when they are called from
 * methods with other transaction attributes.
 */
@Stateless
public class SecondaryBean {

    /**
     * MANDATORY means that a transaction is required but none will be 
     * automatically created. That is, the caller must already have a 
     * transaction.
     */
    @TransactionAttribute(TransactionAttributeType.MANDATORY)
    public void mandatory() {
        System.out.println("NestedTransactionBean.mandatory() called");
    }

    /**
     * NEVER means that a transaction is prohibited. The container will not 
     * automatically suspend existing transactions. The caller must ensure there 
     * is no active transaction.
     */
    @TransactionAttribute(TransactionAttributeType.NEVER)
    public void never() {
        System.out.println("NestedTransactionBean.never() called");
    }
    
}
