drop table integer_store;

create table integer_store (
    id integer primary key,
    val integer
);

insert into integer_store(id,val) values (1,0);