package au.edu.uts.aip.optimistic;

import javax.ejb.*;
import javax.persistence.*;

@Stateless
public class NoteBean {

    @PersistenceContext
    private EntityManager em;
    
    /**
     * Retrieve the Note with id = 1. Normally an EJB such as this would support
     * multiple Notes, but in this particular demo there is only one note that 
     * the user can edit.
     * @return the Note with id = 1
     */
    public Note get() {
        return em.find(Note.class, 1);
    }

    /**
     * Updates the note currently in the database.
     * Uses the version property of the entity to detect concurrent 
     * modifications. If the value of the version suggests that a concurrent 
     * modification has occurred, then an exception is thrown and the 
     * transaction is rolled back.
     * @param note the new value of the note (the version field must be intact)
     * @return the updated note (i.e., with an incremented version).
     * @throws ConcurrentChangeDetected if the note has been concurrently updated by another transaction
     */
    public Note update(Note note) throws ConcurrentChangeDetected {
        try {
            Note merged = em.merge(note);
            em.flush(); // Flush now to check the optimistic lock
            return merged;
        } catch (OptimisticLockException ole) {
            // Throw a user exception so that it can be caught by the caller
            throw new ConcurrentChangeDetected();
        }
    }
    
}
