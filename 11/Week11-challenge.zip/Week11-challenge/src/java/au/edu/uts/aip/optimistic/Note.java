package au.edu.uts.aip.optimistic;

import java.io.*;
import javax.persistence.*;

/**
 * This Entity represents a Note in the database.
 * Even though the user interface only supports a single note, this 
 */
@Entity
public class Note implements Serializable {
    
    @Id
    private int id;
    
    private String text;
    
    @Version
    private int version;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String value) {
        this.text = value;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }
    
}
