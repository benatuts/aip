package au.edu.uts.aip.optimistic;

import javax.ejb.*;
import javax.enterprise.context.*;
import javax.faces.application.*;
import javax.faces.context.*;
import javax.inject.*;

/**
 * This is a JSF backing bean to support editing and display of notes.
 */
@Named
@RequestScoped
public class NoteController {

    /**
     * This stores the most recent value from the database in the event of
     * a concurrent modification.
     */
    private Note concurrentModification;
    
    /**
     * The current model that the user is editing.
     */
    private Note note = new Note();
    
    /**
     * The EJB that provides the basic Note retrieval and update operations.
     */
    @EJB
    private NoteBean noteBean;
    
    /**
     * Get the current value of the Note.
     * @return the current Note that the user is viewing/updating
     */
    public Note getNote() {
        return note;
    }
    
    /**
     * In the event of a concurrent modification, this returns the latest value
     * stored in the database.
     * @return the latest value of the note in the event of a concurrent modification, null otherwise
     */
    public Note getConcurrentModification() {
        return concurrentModification;
    }
    
    /**
     * Retrieve the latest version of the note from the database and store that
     * as the model for this controller. (This method is called by viewActions
     * on the initial page request.
     */
    public void fetchNote() {
        note = noteBean.get();
    }
    
    /**
     * Updates the note in the database.
     * In the user interface a concurrent modification is shown when the 
     * concurrentModification field is non-null. This is not the only approach
     * possible. Instead, I could also have used JSF messages (i.e., error messages).
     * @return the next JSF view to show
     */
    public String updateNote() {
        try {
            // Update the database and get the new version of the record
            note = noteBean.update(note);
            
            // Success! go back to the main menu
            return "index";
            
        } catch (ConcurrentChangeDetected ccd) {
            // There's been a concurrent modification!
            
            // Retrieve the current database state
            // (this could alternatively be handled by generating error/validation messages)
            concurrentModification = noteBean.get();
            
            // Update this version so that the user can override the database when they click update
            note.setVersion(concurrentModification.getVersion());
            
            // Stay on the same page
            return null;
        }
    }
    
    /**
     * A simplified approach to handling concurrent modifications: just 
     * detect the error but only report an error.
     * @return the next JSF view to show
     */
    public String basicUpdateNote() {
        try {
            // Update the database and get the new version of the record
            note = noteBean.update(note);
            
            // Success! go back to the main menu
            return "index";
            
        } catch (ConcurrentChangeDetected ccd) {
            // Something went wrong, so let's just get the latest version
            note = noteBean.get();
            
            // Display an error message
            showError("The record could not be saved because another user has changed the record. Please try again.");
            
            // Stay on the same page
            return null;
        }
    }

    /**
     * Adds a "global" error message to the JSF view.
     * @param message the error message to display to the user
     */
    private void showError(String message) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(message));
    }
    
}
