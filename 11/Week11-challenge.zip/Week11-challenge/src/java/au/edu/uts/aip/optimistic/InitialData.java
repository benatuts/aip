package au.edu.uts.aip.optimistic;

import javax.annotation.*;
import javax.ejb.*;
import javax.persistence.*;

/**
 * This Singleton EJB populates the database with initial data.
 * On startup, it persists a new Note with id = 1 if none already exists.
 */
@Singleton
@Startup
public class InitialData {
    
    @PersistenceContext
    private EntityManager em;
    
    /**
     * Ensures the database contains a note with id = 1.
     * Persists a new instance of note, if necessary.
     */
    @PostConstruct
    public void startup() {
        if (em.find(Note.class, 1) == null) {
            Note note = new Note();
            note.setId(1);
            note.setText("Hello, World");
            note.setVersion(1);
            em.persist(note);
        }
    }
    
}
