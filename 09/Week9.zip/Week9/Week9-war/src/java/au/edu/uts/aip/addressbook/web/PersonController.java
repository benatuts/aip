package au.edu.uts.aip.addressbook.web;

import au.edu.uts.aip.addressbook.domain.*;
import java.io.*;
import javax.ejb.*;
import javax.faces.view.*;
import javax.inject.*;

/**
 * A JSF BackingBean for person{create/edit/delete} views.
 * Note that this view is ViewScoped rather than RequestScoped.
 * The same functionality could be implemented using RequestScoped.
 * However, it would be quite tricky to achieve.
 * This is because the user interface includes a list that is edited "on the go".
 * <p>
 * When you have a h:commandButton (rather than just h:button) inside a 
 * h:dataTable, JSF needs to restore the view before it can decide what to do 
 * with the action.
 * A RequestScoped bean needs to restore all of its properties first.
 * However, a ViewScoped bean is retained for post-back. 
 * This means that there is no need to restore the properties.
 */
@Named
@ViewScoped
public class PersonController implements Serializable {

    @EJB
    private AddressBookBean addressBookBean;

    private Person currentPerson = new Person();
    private ContactMethod currentContact = new ContactMethod();

    /**
     * Initialize the backing bean. Retrieves the details for the person by
     * their id.
     * @param id 
     */
    public void loadPerson(int id) {
        currentPerson = addressBookBean.findPerson(id);
    }

    /**
     * A getter to retrieve the currently active person.
     * @return the current person
     */
    public Person getCurrentPerson() {
        return currentPerson;
    }
    
    /**
     * A getter to retrieve the currently active contact details of the current 
     * person.
     * @return the current contact details
     */
    public ContactMethod getCurrentContact() {
        return currentContact;
    }
    
    
    /**
     * This is an action used to when the user clicks "Create" on the 
     * "personcreate" view. 
     * @return the outcome to edit the just-created person
     */
    public String createPerson() {
        addressBookBean.createPerson(currentPerson);
        return "personedit?faces-redirect=true&person=" + currentPerson.getId();
    }
    
    /**
     * This is an action used to when the user clicks on the "Update" button on 
     * the "personedit" view. 
     * @return the outcome takes the user back to the address book
     */
    public String savePerson() {
        addressBookBean.updatePersonDetails(currentPerson);
        return "addressbook?faces-redirect=true";
    }
    
    /**
     * This is an action used when the user confirms deletion on the 
     * "persondelete" view. 
     * @return the outcome takes the user back to the address book
     */
    public String deletePerson() {
        addressBookBean.deletePerson(currentPerson.getId());
        return "addressbook?faces-redirect=true";
    }
    
    /**
     * This action is used to add new contact details to the current person
     * when the user clicks on "Add Contact" in the "personedit" view. 
     */
    public void addContactToPerson() {
        addressBookBean.addContact(currentPerson, currentContact);
        
        // Clear current contact
        currentContact = new ContactMethod();
    }
    
    /**
     * This action is used to delete a contact from the list of contacts in the
     * "personedit" view
     * @param contact the contact to delete
     */
    public void deleteContact(ContactMethod contact) {
        addressBookBean.deleteContact(contact);
    }
}
