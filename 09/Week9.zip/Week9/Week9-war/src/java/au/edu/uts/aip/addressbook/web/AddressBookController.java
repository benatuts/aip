package au.edu.uts.aip.addressbook.web;

import au.edu.uts.aip.addressbook.domain.*;
import java.io.*;
import java.util.*;
import java.util.logging.*;
import javax.ejb.*;
import javax.enterprise.context.*;
import javax.faces.view.*;
import javax.inject.*;

@Named
@RequestScoped
public class AddressBookController implements Serializable {

    @EJB
    private AddressBookBean addressBookBean;
    
    private List<Person> people;

    
    /**
     * Populates the database with sample data. Called from the 
     * "addressbook_actions" view.
     */
    public void addSampleData() {
        addressBookBean.addSampleData();
    }
    
    /**
     * Dumps details about people with last name Brady to the server log.
     * Called from the "addressbook_actions" view.
     */
    public void dumpBradys() {
        Logger log = Logger.getLogger(this.getClass().getName());
        for (Person p : addressBookBean.findPeopleByLastName("Brady")) {
            log.log(
                Level.INFO, 
                "firstName = {0}, lastName = {1}, dateOfBirth = {2}", 
                new Object[] {p.getFirstName(), p.getLastName(), p.getDateOfBirth()}
            );
        }
    }
    
    /**
     * Getter for the "people" property used in the "addressbook" view.
     * @return a list of all people in the address book
     */
    public List<Person> getPeople() {
        if (people == null) {
            // Cache the database lookup
            people = addressBookBean.findAllPeople();
        }
        return people;
    }
    
}
