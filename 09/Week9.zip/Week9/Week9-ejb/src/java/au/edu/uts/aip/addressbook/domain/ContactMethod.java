package au.edu.uts.aip.addressbook.domain;

import java.io.*;
import javax.persistence.*;
import javax.validation.constraints.*;

/**
 * A contact method is a pair of phone number and phone-number type.
 * Each person has a list of contact methods.
 * @author Benjamin
 */
@Entity
public class ContactMethod implements Serializable {
    private Person person;
    
    private int id;
    private String phoneNumber;
    private PhoneType phoneType;

    @Id
    @GeneratedValue
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @NotNull(message = "Phone number is required")
    @Size(min = 1, message = "Phone number is required")
    @Pattern(
        regexp = "[0-9\\[\\]\\-+ \\(\\)]*",
        message = "A phone number may only contain numbers, spaces and  +()[]")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @Enumerated(EnumType.STRING)
    public PhoneType getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(PhoneType phoneType) {
        this.phoneType = phoneType;
    }

    @ManyToOne
    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
    
}
