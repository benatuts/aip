package au.edu.uts.aip.addressbook.domain;

import java.io.*;
import java.util.*;
import javax.persistence.*;
import javax.validation.constraints.*;

/**
 * A person in the address book.
 * Each person has name, date of birth and a collection of contact methods.
 */
@Entity
@NamedQueries({
    // Find all people by their last name
    @NamedQuery(name = "Person.findByLastName", 
                query = "select p from Person p where p.lastName = :name"),
    // Find all people
    @NamedQuery(name= "Person.findAll",
                query = "select p from Person p")
})
public class Person implements Serializable {

    private int id;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private List<ContactMethod> contacts = new ArrayList<>();

    @Id
    @GeneratedValue
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @NotNull(message = "First name is required")
    @Size(min = 1, message = "First name is required")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @NotNull(message = "Last name is required")
    @Size(min = 1, message = "Last name is required")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @NotNull(message = "Date of birth is required")
    @Temporal(TemporalType.DATE)
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @OneToMany(mappedBy = "person", cascade = CascadeType.ALL)
    public List<ContactMethod> getContacts() {
        return contacts;
    }

    public void setContacts(List<ContactMethod> contacts) {
        this.contacts = contacts;
    }
    
}
