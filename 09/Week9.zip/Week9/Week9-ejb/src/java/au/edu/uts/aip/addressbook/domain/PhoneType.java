package au.edu.uts.aip.addressbook.domain;

/**
 * Defines the categories for phone numbers (i.e., the contact methods of a 
 * person in the address book).
 */
public enum PhoneType {
    
    HOME,
    WORK,
    MOBILE,
    OTHER
    
}
