package au.edu.uts.aip.addressbook.domain;

import java.util.*;
import javax.ejb.*;
import javax.persistence.*;
import javax.persistence.criteria.*;

/**
 * An Address Book that demonstrates the use of JPA.
 * All operations are stateless.
 */
@Stateless
public class AddressBookBean {
    
    @PersistenceContext
    private EntityManager em;
    
    /**
     * Populate the database with sample data.
     */
    public void addSampleData() {
        Person mike = new Person();
        mike.setFirstName("Mike");
        mike.setLastName("Brady");
        mike.setDateOfBirth(new GregorianCalendar(1932, 9, 19).getTime());

        ContactMethod mike1 = new ContactMethod();
        mike1.setPhoneNumber("762-0799");
        mike1.setPhoneType(PhoneType.HOME);
        
        ContactMethod mike2 = new ContactMethod();
        mike2.setPhoneNumber("555-6161");
        mike2.setPhoneType(PhoneType.WORK);
        
        mike.getContacts().add(mike1);
        mike.getContacts().add(mike2);
        mike1.setPerson(mike);
        mike2.setPerson(mike);
        
        Person marcia = new Person();
        marcia.setFirstName("Marcia");
        marcia.setLastName("Brady");
        marcia.setDateOfBirth(new GregorianCalendar(1956, 7, 5).getTime());

        ContactMethod marcia1 = new ContactMethod();
        marcia1.setPhoneNumber("762-0799");
        marcia1.setPhoneType(PhoneType.HOME);
        
        marcia.getContacts().add(marcia1);
        marcia1.setPerson(marcia);
        
        Person alice = new Person();
        alice.setFirstName("Alice");
        alice.setLastName("Nelson");
        alice.setDateOfBirth(new GregorianCalendar(1926, 4, 5).getTime());
        
        ContactMethod alice1 = new ContactMethod();
        alice1.setPhoneNumber("72485899");
        alice1.setPhoneType(PhoneType.MOBILE);
        
        alice.getContacts().add(alice1);
        alice1.setPerson(alice);
        
        em.persist(mike);
        // em.persist(mike1);     // This is not needed because we have cascade=ALL on the Person entity
        // em.persist(mike2);     // This is not needed because we have cascade=ALL on the Person entity
        em.persist(marcia);
        // em.persist(marcia1);   // This is not needed because we have cascade=ALL on the Person entity
        em.persist(alice);
        // em.persist(alice1);    // This is not needed because we have cascade=ALL on the Person entity
    }
    
    /**
     * Retrieves all people in the database.
     * Examples of different ways of querying JPA are have been commented out
     * for reference. You should not leave commented-out code in your assignment
     * submissions.
     * @return a list of people instances in the database
     */
    public List<Person> findAllPeople() {
        // Basic JPA Query
        /*
        TypedQuery<Person> query = em.createQuery("select p from Person p", Person.class);
        return query.getResultList();
        */
        
        // Named Query
        /*
        TypedQuery<Person> query = em.createNamedQuery("Person.findAll", Person.class);
        return query.getResultList();
        */
        
        // Criteria Query
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Person> query = builder.createQuery(Person.class);
        return em.createQuery(query).getResultList();
        
        // Criteria Query with pre-fetching of the contacts relationship
        //
        // This is an advanced approach to improving performance that 
        // avoids the so-called "N+1 Problem" in Object-Relational Mapping
        /*
        CriteriaQuery<Person> query = em.getCriteriaBuilder().createQuery(Person.class);
        Root<Person> from = query.from(Person.class);
        from.fetch(Person_.contacts, JoinType.LEFT);
        query.distinct(true);
        List<Person> people = em.createQuery(query).getResultList();
        return people;
        */
    }
    
    /**
     * Retrieves all people in the database by surname.
     * This function illustrates the use of parameterized queries in JPA
     * Examples of different ways of querying JPA are have been commented out
     * for reference.
     * @param lastName the last name of entities to retrieve from the database
     * @return a list of all matching people instances in the database
     */
    public List<Person> findPeopleByLastName(String lastName) {
        // Basic JPA Query
        /*
        TypedQuery<Person> query = em.createQuery("select p from Person p where p.lastName = :name", Person.class);
        query.setParameter("name", lastName);
        return query.getResultList();
        */
        
        // Named Query
        /*
        TypedQuery<Person> query = em.createNamedQuery("Person.findByLastName", Person.class);
        query.setParameter("name", lastName);
        return query.getResultList();
        */
        
        // Criteria Query
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Person> query = builder.createQuery(Person.class);
        Root<Person> from = query.from(Person.class);
        query.where(builder.equal(from.get(Person_.lastName), lastName));
        return em.createQuery(query).getResultList();
        
        // Criteria Query with pre-fetching of the contacts relationship
        //
        // This is an advanced approach to improving performance that 
        // avoids the so-called "N+1 Problem" in Object-Relational Mapping
        /*
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Person> query = builder.createQuery(Person.class);
        Root<Person> from = query.from(Person.class);
        query.where(builder.equal(from.get(Person_.lastName), lastName));
        from.fetch(Person_.contacts, JoinType.LEFT);
        query.distinct(true);
        return em.createQuery(query).getResultList();
        */
    }

    /**
     * Find a person by their primary key.
     * @param id the unique primary key for the person
     * @return the corresponding Person entity
     */
    public Person findPerson(int id) {
        return em.find(Person.class, id);
    }

    /**
     * Updates the personal details of a person.
     * This method does not update the list of contacts.
     * @param currentPerson a Person object containing the id of the person to 
     *                      update and the personal details
     */
    public void updatePersonDetails(Person currentPerson) {
        em.merge(currentPerson);
    }

    /**
     * Deletes a person from the address book.
     * @param id the unique id of the person to delete
     */
    public void deletePerson(int id) {
        Person person = em.find(Person.class, id);
        em.remove(person);
        
        // If we did not have cascade = ALL, we would need to delete the related
        // contacts, like this:
        /*
        for (ContactMethod contact : person.getContacts())
            em.remove(contact);
        */
    }
    
    /**
     * Create a person in the address book.
     * @param person the person to create in the address book
     */
    public void createPerson(Person person) {
        em.persist(person);
    }

    /**
     * Associates a contact with a person.
     * @param person the person to add the contact to
     * @param contact the new contact details to add to the person
     */
    public void addContact(Person person, ContactMethod contact) {
        Person managed = em.find(Person.class, person.getId());

        // To persist a contact, we need to ensure that it is related to a 
        // managed entity (not another detached entity)
        contact.setPerson(managed);
        
        // Keep the inverse relationship up-to-date
        managed.getContacts().add(contact);
        
        // Update the relationship on the Person entity (if it is a detached entity)
        if (person != managed) {
            person.getContacts().add(contact);
        }
        
        // save changes to the contact (the contact is the "owner" of the relationship)
        em.persist(contact);
    }
    
    /**
     * Deletes a contact from a person.
     * @param contact the contact to delete
     */
    public void deleteContact(ContactMethod contact) {
        // Get an equivalent managed object
        ContactMethod managed = em.find(ContactMethod.class, contact.getId());
        
        // We need to keep the bi-directional relationships up-to-date
        managed.getPerson().getContacts().remove(managed);
        
        // Update the relationship on the Person entity (if it is a detached entity)
        if (managed != contact) {
            contact.getPerson().getContacts().remove(contact);
        }
        
        em.remove(managed);
    }
    
}
