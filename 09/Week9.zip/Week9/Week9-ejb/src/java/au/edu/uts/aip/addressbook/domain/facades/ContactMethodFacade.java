package au.edu.uts.aip.addressbook.domain.facades;

import au.edu.uts.aip.addressbook.domain.ContactMethod;
import javax.ejb.*;
import javax.persistence.*;

/**
 * Basic CRUD-style Session Facade for ContactMethod entities.
 */
@Stateless
public class ContactMethodFacade extends AbstractFacade<ContactMethod> {
    
    @PersistenceContext
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ContactMethodFacade() {
        super(ContactMethod.class);
    }
    
}
