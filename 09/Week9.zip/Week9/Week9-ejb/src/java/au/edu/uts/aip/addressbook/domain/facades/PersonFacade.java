package au.edu.uts.aip.addressbook.domain.facades;

import au.edu.uts.aip.addressbook.domain.Person;
import javax.ejb.*;
import javax.persistence.*;

/**
 * Basic CRUD-style Session Facade for ContactMethod entities.
 */
@Stateless
public class PersonFacade extends AbstractFacade<Person> {
    
    @PersistenceContext
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PersonFacade() {
        super(Person.class);
    }
    
}
