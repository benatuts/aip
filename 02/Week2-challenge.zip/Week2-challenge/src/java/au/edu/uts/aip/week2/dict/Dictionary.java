package au.edu.uts.aip.week2.dict;

import java.io.*;
import java.util.*;

/**
 * This class contains the application logic of a dictionary app.
 * It allows lookup by either language and returns a list of matches.
 * It is not efficient. It simply tests every entry for a match.
 * Comparisons are case-insensitive.
 * <p>
 * A database might be a good place to store and query this data.
 * However, we have not covered it in lectures yet, so I'm storing it in memory.
 * You might also consider using something like Apache Lucene for the text searching.
 */
public class Dictionary {
    
    private ArrayList<Definition> definitions;
    
    public Dictionary() {
        definitions = new ArrayList<Definition>();
    }

    /**
     * Load the contents of a dictionary file from an input stream.
     * The file is assumed to have dictionary pairs on successive lines.
     * First, the foreign language term.
     * Second, the English language definition.
     * 
     * @param fileName the input stream containing dictionary data
     * @throws IOException 
     */
    public void load(InputStream dictionaryFile) throws IOException {
        Reader fileChars = new InputStreamReader(dictionaryFile, "UTF-8");
        BufferedReader reader = new BufferedReader(fileChars);
        String translation;
        String english;
        while ((translation = reader.readLine()) != null && (english = reader.readLine()) != null) {
            definitions.add(new Definition(translation, english));
        }
    }
    
    /**
     * Searches the list of translated language pairs.
     * Returns a list of all that match the supplied English term.
     * The comparison is case-insensitive.
     * 
     * @param substring the English word to search
     * @return a list of all matching terms
     */
    public List<Definition> fromEnglish(String substring) {
        String lower = substring.toLowerCase();
        ArrayList<Definition> results = new ArrayList();
        for (Definition d : definitions) {
            if (d.matchesEnglish(lower)) {
                results.add(d);
            }
        }
        return results;
    }
    
    /**
     * Searches the list of translated language pairs.
     * Returns a list of all that match the supplied foreign language term.
     * The comparison is case-insensitive.
     * 
     * @param substring the foreign language word to search
     * @return a list of all matching terms
     */
    public List<Definition> toEnglish(String substring) {
        String lower = substring.toLowerCase();
        ArrayList<Definition> results = new ArrayList();
        for (Definition d : definitions) {
            if (d.matchesTranslation(lower)) {
                results.add(d);
            }
        }
        return results;
    }
    
}
