package au.edu.uts.aip.week2.dict;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * A translation dictionary Servlet.
 * Takes HTTP GET parameter named either: 
 * english (an English word to translate to the foreign language)
 * or 
 * translation (a foreign language word to translate to English.
 * Only one parameter value should be present.
 * <p>
 * The dictionary file is configurable using the context-parameter named dictionary (set in web.xml).
 */
@WebServlet("/Dictionary")
public class DictionaryServlet extends HttpServlet {

    private Dictionary dictionary;
    
    /**
     * Loads the dictionary into memory from the file specified in the servlet context.
     * 
     * @throws ServletException 
     */
    @Override
    public void init() throws ServletException {
        dictionary = new Dictionary();
        
        // The dictionary filename is configured in web.xml
        String fileName = getServletContext().getInitParameter("dictionary");
        
        // This loads a file from our deployed WAR file
        InputStream file = getServletContext().getResourceAsStream(fileName);
        try {
            dictionary.load(file);
        } catch (IOException ioe) {
            throw new ServletException(ioe);
        }
    }
    
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/html");
        
        try (PrintWriter out = response.getWriter()) {
            String english = request.getParameter("english");
            String translation = request.getParameter("translation");
            
            if (english == null && translation == null) {
                
                // Uh oh! The user hasn't supplied any parameters
                generateErrorMessage(out);
                
            } else {
            
                // Look up the translations
                boolean toEnglish;
                String word;
                List<Definition> results;

                if (english != null) {
                    word = english;
                    toEnglish = false;
                    results = dictionary.fromEnglish(english);
                } else {
                    word = translation;
                    toEnglish = true;
                    results = dictionary.toEnglish(translation);
                }

                // Render the results to the user
                if (results.isEmpty()) {
                    generateNoResults(out, toEnglish, word);
                } else {
                    generateResults(out, toEnglish, word, results);
                }

            }
        }
    }
    
    private void generateHeader(PrintWriter out) {
        // This would be better using JavaServer Pages, but we cover that next week
        
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head><title>Dictionary</title></head>");
        out.println("<body>");
    }
    
    private void generateFooter(PrintWriter out) {
        // This would be better using JavaServer Pages, but we cover that next week
        
        out.println("</body>");
        out.println("</html>");
    }
    
    private void generateErrorMessage(PrintWriter out) {
        // This would be better using JavaServer Pages, but we cover that next week
        generateHeader(out);
        out.println("<h1>Error</h1>");
        out.println("<p>Missing form values</p>");
        generateFooter(out);
    }
    
    private void generateNoResults(PrintWriter out, boolean toEnglish, String word) {
        // This would be better using JavaServer Pages, but we cover that next week
        
        generateHeader(out);
        
        String direction = toEnglish ? "to English" : "from English";
        
        out.println("<h1>Translation " + direction + "</h1>");
        out.println(
                "<p>Your word, " + word +
                ", translated " + direction + 
                " could not be found in the dictionary.</p>"
            );
        
        generateFooter(out);
    }
    
    private void generateResults(PrintWriter out, boolean toEnglish, String word, List<Definition> results) {
        // This would be better using JavaServer Pages, but we cover that next week
        
        generateHeader(out);
        
        String direction = toEnglish ? "to English" : "from English";
        
        out.println("<h1>Translation " + direction + "</h1>");
        out.println(
            "<p>Your word, " + word +
            ", translated " + direction + 
            " is: </p>"
        );

        // Show each term in both languages
        out.println("<ul>");
        for (Definition result : results) {
            out.println(
                "<li>" + result.getTranslation() + 
                "<br/>" + result.getEnglish() + "</li>"
            );
        }
        out.println("</ul>");
        
        generateFooter(out);
    }

}
