package au.edu.uts.aip.week2.dict;

/**
 * A pair of terms: a foreign language term and the English translation.
 */
public class Definition {
    
    private String translation;
    private String english;
    
    private String translationLower; // cached conversion to lowercase
    private String englishLower; // cached conversion to lowercase

    public Definition(String translation, String english) {
        this.translation = translation;
        this.english = english;
        
        // convert to lower case to do efficient case-insensitive matching
        this.translationLower = translation.toLowerCase();
        this.englishLower = english.toLowerCase();
    }
    
    public String getTranslation() {
        return translation;
    }
    
    public String getEnglish() {
        return english;
    }
    
    /**
     * Checks to see if the parameter is contained within the English definition.
     * The comparison is case insensitive.
     * 
     * @param lower the substring used to search the English definition
     * @return true if the substring is found in the English
     */
    public boolean matchesEnglish(String lower) {
        return englishLower.contains(lower);
    }
    
    /**
     * Checks to see if the parameter is contained within the foreign language term.
     * The comparison is case insensitive.
     * 
     * @param lower the substring used to search the foreign language term
     * @return true if the substring is found in the foreign language term
     */
    public boolean matchesTranslation(String lower) {
        return translationLower.contains(lower);
    }
    
}
