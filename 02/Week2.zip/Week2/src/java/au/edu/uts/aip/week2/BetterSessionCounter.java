package au.edu.uts.aip.week2;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

/**
 * This class is an improved design of the SessionCounter.
 * The logic for counting should be the same for the global and session counts.
 * Therefore, it makes sense to move the counter logic to a new class.
 * In this case, I called that class "RequestCounter".
 */
@WebServlet("/BetterSessionCounter")
public class BetterSessionCounter extends HttpServlet {

    private RequestCounter globalCount = new RequestCounter();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get the user count from the session
        HttpSession session = request.getSession();
        RequestCounter userCount = (RequestCounter)session.getAttribute("userCount");
        
        // Create a user count if one does not exist
        if (session.isNew() || null == userCount) {
            userCount = new RequestCounter();
            session.setAttribute("userCount", userCount);
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Counter</title>");
        out.println("<body>");
        out.println("<p>Number of requests since reload: " + globalCount.increaseCounter() + "</p>");
        out.println("<p>Number of requests in this session: " + userCount.increaseCounter() + "</p>");
        String url = response.encodeURL("BetterSessionCounter");
        out.println("<p><a href=\"" + url + "\">Reload this page</a></p>");
        out.println("</body>");
        out.println("</html>");
    }

}