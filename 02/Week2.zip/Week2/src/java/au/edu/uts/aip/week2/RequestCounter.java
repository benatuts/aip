package au.edu.uts.aip.week2;

import java.io.*;

/**
 * This class keeps track of the number of page requests.
 * <p>
 * It is a "helper" class used by the "BetterSessionCounter" servlet.
 * <p>
 * This class "implements Serializable".
 * Anything that goes in a session <b>should</b> implement Serializable.
 * This tells the application server that it is safe to store session data in a database (if it needs to).
 */
public class RequestCounter implements Serializable {
    
    public int counter = 0;
    
    public synchronized int increaseCounter() {
        counter = counter + 1;
        return counter;
    }
    
    public synchronized int getValue() {
        return counter;
    }
}
