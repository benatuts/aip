package au.edu.uts.aip.week2;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/SettableCounter")
public class SettableCounter extends HttpServlet {

    private static int counter = 0;

    private synchronized int increaseCounter() {
        counter = counter + 1;
        return counter;
    }
    
    private synchronized void setCounter(int value) {
        counter = value;
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        
        String newValueString = request.getParameter("newValue");
        
        String message;
        
        if (null == newValueString) {
            message = "The current value of the counter: " + increaseCounter();
        } else {
            try {
                int newValue = Integer.parseInt(newValueString);
                setCounter(newValue);
                message = "The counter has been set: " + newValue;
            } catch (NumberFormatException nfe) {
                message = "You supplied an invalid number";
            }
        }
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Settable Counter</title>");
        out.println("<body><p>" + message + "</p></body>");
        out.println("</html>");
    }

}