package au.edu.uts.aip.week2;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/SessionCounter")
public class SessionCounter extends HttpServlet {

    private int globalCounter = 0;

    private synchronized int increaseGlobalCounter() {
        globalCounter = globalCounter + 1;
        return globalCounter;
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Integer sessionCounter = (Integer)session.getAttribute("sessionCounter");

        int userCounter;
        if (session.isNew() || null == sessionCounter) {
            userCounter = 1;
        } else {
            userCounter = sessionCounter + 1;
        }
        session.setAttribute("sessionCounter", userCounter);
        
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Counter</title>");
        out.println("<body>");
        out.println("<p>Number of requests since reload: " + increaseGlobalCounter() + "</p>");
        out.println("<p>Number of requests in this session: " + userCounter + "</p>");
        String url = response.encodeURL("SessionCounter");
        out.println("<p><a href=\"" + url + "\">Reload this page</a></p>");
        out.println("</body>");
        out.println("</html>");
    }

}