package au.edu.uts.aip.week2;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/Counter")
public class Counter extends HttpServlet {

    private int counter = 0;

    private synchronized int increaseCounter() {
        counter = counter + 1;
        return counter;
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int newCount = increaseCounter();
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>Counter</title>");
        out.println("<body><p>Number of requests since reload: " + newCount + "</p></body>");
        out.println("</html>");

    }

}