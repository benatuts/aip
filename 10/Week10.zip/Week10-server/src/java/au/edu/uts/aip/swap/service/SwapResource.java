package au.edu.uts.aip.swap.service;

import au.edu.uts.aip.swap.domain.*;
import javax.ejb.*;
import javax.ws.rs.*;

/**
 * A JAX-RS Resource that provides a message exchange service. A message posted 
 * to /api/swap will be given to the next person to use the service, and will 
 * return the message submitted by the previous user.
 */
@Path("swap")
public class SwapResource {
    
    @EJB
    private SwapBean swapBean;
    
    /**
     * This default constructor is used to show that by default JAX-RS uses 
     * a new instance to handle each request. In the server log, you will see
     * "A new instance of SwapService was created" for each request."
     */
    public SwapResource() {
        System.out.println("A new instance of SwapService was created");
    }
    
    /**
     * Peeks at the message currently awaiting delivery.
     * @return the next message that will be returned by swap()
     */
    @GET
    public Message peek() {
        return swapBean.peek();
    }

    /**
     * Swaps a new message with the message currently on the server.
     * The idea is that users will post a message and, in return, they receive
     * the message of the previous person who had posted a message.
     * @param message the message to post for the next person
     * @return the message previously posted
     */
    @POST
    public Message swap(Message message) {
        return swapBean.swap(message);
    }
    
}
