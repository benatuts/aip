package au.edu.uts.aip.swap.domain;

import java.util.*;
import javax.annotation.*;
import javax.ejb.*;

/**
 * A Singleton EJB that manages the domain logic of the "Text Exchange" social
 * game. A message can be swapped with the previous message that was supplied.
 */
@Singleton
public class SwapBean {

    private Message currentMessage;
    
    /**
     * After initialization, sets up a default message so that the first user
     * will receive something useful.
     */
    @PostConstruct
    protected void init() {
        currentMessage = new Message();
        currentMessage.setMessage("Coding at Bondi Beach...");
        currentMessage.setTime(new Date());
        currentMessage.setLatitude(-33.890843);
        currentMessage.setLongitude(151.280056);
    }
    
    /**
     * Swaps a new message with the message currently held in the bean.
     * @param message the new message posted by a user, to deliver to the next user
     * @return the message previously posted by the user
     */
    public Message swap(Message message) {
        Message result = currentMessage;
        currentMessage = message;
        return result;
    }
    
    /**
     * Peeks at the next message that will be returned by the swap(Message) method.
     * @return the next message that will be delivered to a user
     */
    public Message peek() {
        return currentMessage;
    }
    
}
