package au.edu.uts.aip.swap.service;

import javax.ws.rs.*;
import javax.ws.rs.core.*;

/** 
 * JAX-RS configuration to host JAX-RS web services under the /api/ path.
 */
@ApplicationPath("api")
public class ApplicationConfig extends Application {
    
}
