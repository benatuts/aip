package au.edu.uts.aip.swap.web;

import java.util.*;
import java.util.logging.*;
import javax.annotation.Resource;
import javax.enterprise.context.*;
import javax.faces.application.*;
import javax.faces.context.*;
import javax.inject.*;
import javax.ws.rs.*;
import javax.ws.rs.client.*;

/**
 * A backing bean for the "Text Exchange" application.
 * Swaps a message with the Week11-server using JAX-RS client.
 */
@Named
@RequestScoped
public class SwapController {
    
    /**
     * The URL of the RESTful web service.
     * This is configured in web.xml.
     */
    @Resource(name = "swapService")
    String swapService;
    
    private SwapMessage request = new SwapMessage();
    private SwapMessage response;

    public SwapMessage getRequest() {
        return request;
    }

    public SwapMessage getResponse() {
        return response;
    }
    
    /**
     * An action used by the compose.xhtml view.
     * This action submits the user's request to the RESTful web service.
     * The receive.xhtml view is used to show the received response.
     * Faces messages are used to report any errors.
     * @return null if an error occurred, "receive" otherwise
     */
    public String swap() {
        // Set the time of the message to "Now"
        request.setTime(new Date());
        
        // POST to the swap web service
        // The web service takes an instance of SwapMessage (request)
        // and returns an instance of SwapMessage (response)
        Client client = null;
        try {
            // Client is a "heavy" object.
            // We are creating a new one here with each request but it could be 
            // reused if we were using it in a stateless session bean, for example.
            client = ClientBuilder.newClient();
            
            response = client.target(swapService)
                             .request()
                             .post(Entity.xml(request), SwapMessage.class);
            
        } catch (ProcessingException | WebApplicationException e) {
            Logger log = Logger.getLogger(this.getClass().getName());
            log.log(Level.SEVERE, "Could not communicate with swap web service", e);
            
            FacesContext context = FacesContext.getCurrentInstance();
            context.addMessage(null, new FacesMessage("An error occurred communicating with the Text Exchange server, please try again later"));
            // Stay on the same page in the event of an error
            return null;
        } finally {
            // make sure that client is closed, if it was created
            if (client != null)
                client.close();
        }
        
        // Render the resulting message
        return "receive";
    }
    
}
