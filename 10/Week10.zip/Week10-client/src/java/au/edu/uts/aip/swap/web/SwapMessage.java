package au.edu.uts.aip.swap.web;

import java.io.*;
import java.util.*;
import javax.xml.bind.annotation.*;

/**
 * A JAXB-annotated class used for serialization and deserialization of messages
 * used by the "swap" RESTful web service. The same message format is used for 
 * both sending a message and receiving a response. The same message format is 
 * used for both XML and JSON binding.
 */
@XmlRootElement(name = "message")
public class SwapMessage implements Serializable {

    private String message;
    private Date time;
    private double latitude;
    private double longitude;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @XmlElement(name = "lat")
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    @XmlElement(name = "long")
    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
    
}
