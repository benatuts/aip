
if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
        function(position) {
            var lat = document.getElementById("request:lat");
            var long = document.getElementById("request:long");
            lat.value = position.coords.latitude;
            long.value = position.coords.longitude;
        }
    );
}
