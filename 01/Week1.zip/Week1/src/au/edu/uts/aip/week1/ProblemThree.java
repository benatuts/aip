package au.edu.uts.aip.week1;

/**
 * Main class for a solution to Problem 3.
 * <p>
 * To run this file, right click on the class name in the Project view and then 
 * click "Run".
 */
public class ProblemThree {

    public static void main(String[] args) {
        RandomColorGenerator generator = new RandomColorGenerator();
        
        String result = "";
        for (int i=0; i<10; i++) {
            ColorView color = new ColorView(generator.generate());
            result += color.toHTML();
       }
    
        MiniBrowser.show(result);
    }
    
}
