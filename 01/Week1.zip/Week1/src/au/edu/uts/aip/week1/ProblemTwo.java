package au.edu.uts.aip.week1;

/**
 * Main class for a solution to Problem 2.
 * <p>
 * To run this file, right click on the class name in the Project view and then 
 * click "Run".
 */
public class ProblemTwo {
    
    public static void main(String[] args) {
        
        String result = "";

        // Create 10 <div> elements
        for (int divNo=0; divNo<10; divNo++) {
            
            // Generate a random color
            String color = "#";
            for (int i=0; i<6; i++) {
                int random = (int)(Math.random() * 16);
                color = color + Integer.toHexString(random);
            }

            // Insert the random color into HTML
            String before = "<div style=\"background-color:";
            String after = "\">This has a random color</div>";
            result += before + color + after;
        }
        
        MiniBrowser.show(result);
    }
    
}
