package au.edu.uts.aip.week1;

/**
 * A class that stores contact information about a person.
 */
public class Person {
    
    private String firstName;
    private String lastName;
    private String phone;
    
    /**
     * Creates a new contact (i.e., a person)
     * @param firstName the person's first name
     * @param lastName the person's last name
     * @param phone the person's telephone or mobile number
     */
    public Person(String firstName, String lastName, String phone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
    }
    
    /**
     * Generates a HTML representation of a person.
     * <p>
     * Produces a HTML table row (tr) containing the person details: their first name, last name and phone number.
     * @return a HTML tr table row for the person details
     */
    public String toHTML() {
        return "<tr><td>" +
                firstName +
                "</td><td>" +
                lastName +
                "</td><td>" +
                phone +
                "</td></tr>";
    }
    
}
