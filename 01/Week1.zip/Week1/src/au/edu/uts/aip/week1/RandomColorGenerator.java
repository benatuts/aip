package au.edu.uts.aip.week1;

/**
 * Generates a random CSS color.
 */
public class RandomColorGenerator {

    /**
     * Generate a random CSS color (e.g., #fe8d05)
     * @return a random CSS color
     */
    public String generate() {
        String color = "#";
        for (int i=0; i<6; i++) {
            int random = (int)(Math.random() * 16);
            color = color + Integer.toHexString(random);
        }
        return color;
    }
    
}
