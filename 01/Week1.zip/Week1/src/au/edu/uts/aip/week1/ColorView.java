package au.edu.uts.aip.week1;

/**
 * Generates a HTML preview from a CSS color code.
 */
public class ColorView {
    
    private String color;

    /**
     * Creates a color view.
     * @param color a CSS color code (e.g., #ffee00).
     */
    public ColorView(String color) {
        this.color = color;
    }
    
    /**
     * Generates a HTML preview of a CSS color code
     * @return a HTML div with the previewed background color
     */
    public String toHTML() {
        String before = "<div style=\"background-color:";
        String after = "\">This has a random color</div>";
        return before + color + after;
    }
    
}
