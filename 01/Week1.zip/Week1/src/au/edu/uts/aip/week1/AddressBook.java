package au.edu.uts.aip.week1;

import java.util.*;

/**
 * An AddressBook is a collection of People (i.e., contacts).
 */
public class AddressBook {

    /**
     * The addresses in the address book.
     */
    private ArrayList<Person> contacts;
    
    public AddressBook() {
        contacts = new ArrayList<Person>();
    }
    
    /**
     * Adds a contact to the address book.
     * @param person the contact to add
     */
    public void add(Person person) {
        contacts.add(person);
    }

    /**
     * Generates a HTML representation of the address book.
     * <p>
     * The address book is generated in a HTML table structure.
     * Each row corresponds to an address.
     * @return a HTML table representation of the address book 
     */
    public String toHtml() {
        String result = "<table>";
        result += "<tr><th>First Name</th><th>Last Name</th><th>Phone Number</th></tr>";
        for (Person p : contacts) {
            result += p.toHTML();
        }
        result += "</table>";
        return result;
    }
    
}
