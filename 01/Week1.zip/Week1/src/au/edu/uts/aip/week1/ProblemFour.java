package au.edu.uts.aip.week1;

/**
 * Main class for a solution to Problem 4.
 * <p>
 * To run this file, right click on the class name in the Project view and then 
 * click "Run".
 */
public class ProblemFour {
    
    public static void main(String[] args) {
        // Set up an array with four contacts
        Person[] contacts = new Person[4];
        contacts[0] = new Person("Carol", "Brady", "762-0799");
        contacts[1] = new Person("Mike", "Brady", "762-0799");
        contacts[2] = new Person("Alice", "Nelson", "762-3141");
        contacts[3] = new Person("Sam", "Franklin", "762-2718");

        // Output the array as a table
        String result = "<table>";
        result = result + "<tr><th>First Name</th><th>Last Name</th><th>Phone Number</th></tr>";
        for (Person p : contacts) {
            result = result + p.toHTML();
        }
        result = result + "</table>";
        
        MiniBrowser.show(result);
    }
    
}
