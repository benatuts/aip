package au.edu.uts.aip.week1;

/**
 * Main class for a solution to Challenge 5.
 * <p>
 * To run this file, right click on the class name in the Project view and then 
 * click "Run".
 */
public class ProblemFive {
    
    public static void main(String[] args) {
        AddressBook contacts = new AddressBook();
        contacts.add(new Person("Carol", "Brady", "762-0799"));
        contacts.add(new Person("Mike", "Brady", "762-0799"));
        contacts.add(new Person("Alice", "Nelson", "762-3141"));
        contacts.add(new Person("Sam", "Franklin", "762-2718"));
        
        MiniBrowser.show(contacts.toHtml());
    }
    
}
