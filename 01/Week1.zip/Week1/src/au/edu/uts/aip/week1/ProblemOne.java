package au.edu.uts.aip.week1;

/**
 * Main class for a solution to Problem 1.
 * <p>
 * To run this file, right click on the class name in the Project view and then 
 * click "Run".
 */
public class ProblemOne {
    
    public static void main(String[] args) {
        String result = "";

        // Append the 6 header levels
        for (int i=1; i<7; i++) {
            result += "<h"+ i +">This is a H"+ i +" heading</h" + i +">";
        }
        
        MiniBrowser.show(result);
    }
    
}
