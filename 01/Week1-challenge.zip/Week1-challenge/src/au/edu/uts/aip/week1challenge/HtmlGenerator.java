package au.edu.uts.aip.week1challenge;

/**
 * A HTML Generator is able to format a supplied object into a HTML representation.
 * @param <T> the type of object to be formatted
 */
@FunctionalInterface
public interface HtmlGenerator<T> {
    
    /**
     * Transforms the supplied object into a HTML representation.
     * @param object the object to format
     * @return the object transformed into HTML
     */
    public String format(T object);
    
}
