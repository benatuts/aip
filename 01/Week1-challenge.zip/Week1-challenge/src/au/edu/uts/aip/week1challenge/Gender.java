package au.edu.uts.aip.week1challenge;

/**
 * An enum representing the (possibly unknown) gender of a person in an address book.
 */
public enum Gender {
    
    FEMALE("Female"),
    MALE("Male"),
    OTHER("Other"),
    UNKNOWN("Unknown");
    
    private String description;
    
    private Gender(String description) {
        this.description = description;
    }
    
    @Override
    public String toString() {
        return description;
    }
    
}
