package au.edu.uts.aip.week1challenge;

import java.util.*;

public class Person {
    
    private String firstName;
    private String lastName;
    private String phone;
    private Date dateOfBirth;
    private Gender gender;
    
    /**
     * Creates a new contact (i.e., a person)
     * @param firstName the person's first name
     * @param lastName the person's last name
     * @param phone the person's telephone or mobile number
     * @param dateOfBirth the person's birth date
     * @param gender the gender of the person
     */
    public Person(String firstName, String lastName, String phone, Date dateOfBirth, Gender gender) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.dateOfBirth = dateOfBirth;
        this.gender = gender;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }
    
}
