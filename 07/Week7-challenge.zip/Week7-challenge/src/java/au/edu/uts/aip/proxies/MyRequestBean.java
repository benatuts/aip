package au.edu.uts.aip.proxies;

import javax.enterprise.context.*;

/**
 * A bean to be injected into another class.
 */
@RequestScoped
public class MyRequestBean {
    
    private static volatile int uniqueCountGenerator;
    private int count = uniqueCountGenerator++;

    /**
     * Get an internally generated identifier of this object.
     * @return the count property
     */
    public int getCount() {
        return count;
    }
    
    /**
     * Get the system "identity hashcode" as determined by this object.
     * @return identity hashcode
     */
    public int getIdentityHashCode() {
        return System.identityHashCode(this);
    }

    /**
     * Get the name of the class that this object is an instance of.
     * @return name of this object's type
     */
    public String getClassName() {
        return this.getClass().getName();
    }
    
}
