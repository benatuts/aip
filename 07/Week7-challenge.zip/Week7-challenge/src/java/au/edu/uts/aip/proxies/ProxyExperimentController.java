package au.edu.uts.aip.proxies;

import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A Backing Bean to examine the difference between an object and a proxy for
 * an object.
 */
@Named
@SessionScoped
public class ProxyExperimentController implements Serializable {

    /**
     * Inject an object. If the lifespan of this object is longer than the
     * injected object, then the container needs to use a proxy.
     */
    @Inject
    MyRequestBean injected;
    
    
    /**
     * Get the instance of the injected object. This will be a reference to a
     * proxy that pretends to be the target object.
     * @return the injected proxy
     */
    public MyRequestBean getInjected() {
        return injected;
    }
    
    /**
     * Get the count of the injected object.
     * @return current count of proxied object
     */
    public int getCount() {
        return injected.getCount();
    }
    
    /**
     * Get the class name of the injected object.
     * @return the class name of the proxy
     */
    public String getProxyClassName() {
        return injected.getClass().getName();
    }
    
    /**
     * Get the name of the class that the object itself believes it to be.
     * @return the type of the proxied object, according to the object itself
     */
    public String getBeanClassName() {
        return injected.getClassName();
    }
    
    /**
     * Get the system identity hashcode of the injected object.
     * @return the identity of the proxy
     */
    public int getProxyIdentity() {
        return System.identityHashCode(injected);
    }
    
    /**
     * Get the system identity hashcode that the object itself believes it to be.
     * @return the identity of the proxied object, according to the object itself
     */
    public int getBeanIdentity() {
        return injected.getIdentityHashCode();
    }
    
    /**
     * Extract the underlying object from the injected proxied object
     * @return the unproxied object
     */
    public MyRequestBean getUnderlyingObject() throws NoSuchMethodException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        // WARNING!!!! This is implementation specific
        // It depends on knowledge that "Weld" is used to do injection
        // It is not guaranteed to work on other application servers
        Object target = injected.getClass().getMethod("getTargetInstance").invoke(injected);
        return (MyRequestBean)target;
    }
    
    /**
     * Get a list of interfaces an object supports.
     * @param object the object to examine
     * @return the interfaces declared by the type of the object
     */
    public List<Class> getInterfaces(Object object) {
        return Arrays.asList(object.getClass().getInterfaces());
    }
    
    /**
     * Get the type of an object and all of its supertypes.
     * @param object the object to examine
     * @return the classes and superclasses of the object
     */
    public List<Class> getAncestry(Object object) {
        ArrayList<Class> allClasses = new ArrayList<>();
        Class current = object.getClass();
        while (current != null) {
            allClasses.add(current);
            current = current.getSuperclass();
        }
        return allClasses;
    }
    
    /**
     * Get all fields (public/private/static) declared in a class.
     * @param clazz the class to examine
     * @return the fields declared in a class (but not in any superclasses)
     */
    public List<Field> getFields(Class clazz) {
        Field[] fields = clazz.getDeclaredFields();
        // Make private fields readable
        for (Field field : fields)
            field.setAccessible(true);
        return Arrays.asList(fields);
    }
    
    /**
     * Get all methods (public/private/static) declared in a class.
     * @param clazz the class to examine
     * @return the methods declared in a class (but not in any superclasses)
     */
    public List<Method> getMethods(Class clazz) {
        return Arrays.asList(clazz.getDeclaredMethods());
    }
    
}
