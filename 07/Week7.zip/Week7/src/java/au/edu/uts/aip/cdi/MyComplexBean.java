package au.edu.uts.aip.cdi;

import java.io.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * This is a slightly more complex bean that generates a unique ID for each instance.
 * This class contains a reference to MySimpleBean that is obtained by 
 * dependency injection. It is used (inside MySessionBean) to show the 
 * possibility of having 'chains' of CDI injection and the consequences of using 
 * 'new' instead of @Inject.
 */
@Dependent
public class MyComplexBean implements Serializable {
    
    @Inject
    private MySimpleBean simple;
    
    private int uniqueId = UniqueIdGenerator.generate();
    
    public int getUniqueId() {
        return uniqueId;
    }

    /**
     * Retrieves the MySimpleBean contained inside this 'MyComplexBean'.
     * @return the simple bean that was injected by CDI
     */
    public MySimpleBean getSimple() {
        return simple;
    }
}
