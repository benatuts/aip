package au.edu.uts.aip.cdi;

import java.io.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * This class is RequestScoped and generates a unique ID for each instance.
 * RequestScoped means that one instance is created for each HTTP request.
 */
@Named
@RequestScoped
public class MyRequestBean implements Serializable {
    
    private int uniqueId = UniqueIdGenerator.generate();
    
    public int getUniqueId() {
        return uniqueId;
    }

}
