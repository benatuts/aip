package au.edu.uts.aip.cdi;

import java.io.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * This class is ApplicationScoped and generates a unique ID for each instance.
 * ApplicationScoped means that just one instance is created across the entire application.
 */
@Named
@ApplicationScoped
public class MyApplicationBean implements Serializable {
    
    private int uniqueId = UniqueIdGenerator.generate();
    
    public int getUniqueId() {
        return uniqueId;
    }
    
}
