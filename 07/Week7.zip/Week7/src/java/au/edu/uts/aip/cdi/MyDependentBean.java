package au.edu.uts.aip.cdi;

import java.io.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * This class is Dependent and generates a unique ID for each instance.
 * Dependent means that:
 * <ul>
 * <li>A new object is created each time it is used (i.e., "@Inject"ed)
 * <li>The scope of this bean becomes that of the bean that it is injected into.
 * </ul>
 */
@Named
@Dependent
public class MyDependentBean implements Serializable {
    
    private int uniqueId = UniqueIdGenerator.generate();
    
    public int getUniqueId() {
        return uniqueId;
    }
    
}
