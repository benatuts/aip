package au.edu.uts.aip.cdi;

import java.io.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * This class is SessionScoped and generates a unique ID for each instance.
 * SessionScoped means that one instance is created per browser session (i.e., as tracked using Cookies).
 */
@Named
@SessionScoped
public class MySessionBean implements Serializable {
    
    private int uniqueId = UniqueIdGenerator.generate();
    
    public int getUniqueId() {
        return uniqueId;
    }
    
    //--------------------------------------------------------------------------
    // The following code is used for the second activity in the tutorial
    
    /**
     * CDI will inject an instance of MySimpleBean here.
     */
    @Inject
    MySimpleBean simple;
    
    /**
     * CDI will inject an instance of MySimpleBean here.
     */
    @Inject
    MyComplexBean complexByInject;
    
    /**
     * Because we are using "new", CDI does not have any involvement in the 
     * creation of this bean. We will see that this means that CDI cannot
     * do dependency injection to create the MySimpleBean embedded within the 
     * complex bean.
     */
    MyComplexBean complexByNew = new MyComplexBean();

    //--------------------------------------------------------------------------
    // 'Getters' for the above beans that have been injected or instantiated
    
    public MySimpleBean getSimple() {
        return simple;
    }

    public MyComplexBean getComplexByInject() {
        return complexByInject;
    }

    public MyComplexBean getComplexByNew() {
        return complexByNew;
    }
    
}
