package au.edu.uts.aip.cdi;

import java.io.*;
import javax.enterprise.context.*;

/**
 * This simple bean class generates a unique ID for each instance.
 * It is used by MyComplexBean to show the possibility of having 'chains' of CDI
 * injection and the consequences of using 'new' instead of @Inject.
 */
@Dependent
public class MySimpleBean implements Serializable {
    
    private int uniqueId = UniqueIdGenerator.generate();
    
    public int getUniqueId() {
        return uniqueId;
    }
}
