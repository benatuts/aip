package au.edu.uts.aip.advice;

import javax.inject.*;
import javax.enterprise.context.*;

/**
 * A simple backing bean for giving bad advice.
 */
@Named
@RequestScoped
public class QuestionController {

    /**
     * Randomly choose between the morecats and newgown outcomes with equal chance.
     * @return morecats or newgown with 50/50 probability
     */
    public String doSuggestion() {
        if (Math.random() < 0.5) {
            return "morecats";
        } else {
            return "newgown";
        }
    }
    
}
