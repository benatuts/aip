package au.edu.uts.aip.waitinglist;

import java.io.*;
import java.util.*;

/**
 * A simple class that acts as an in-memory database of instances of Group.
 * This class provides basic CRUD operations and is a simple substitute for a
 * real database (we cover databases next week).
 */
public class WaitingListDatabase implements Serializable {

    private static int idGenerator;
    
    /**
     * Generate a unique database ID.
     * @return a unique number
     */
    private static synchronized int generateUniqueId() {
        idGenerator++;
        return idGenerator;
    }
    
    // the storage of all records
    private static LinkedHashMap<Integer, Group> groups = new LinkedHashMap<>();
    
    /**
     * All records in the database.
     * @return a collection containing all the Group objects in the database.
     */
    public static Collection<Group> findAll() {
        return groups.values();
    }
    
    /**
     * Creates a new Group in the database.
     * Assigns a unique id to the group and stores the object in memory.
     * @param group the group to add
     */
    public static void create(Group group) {
        group.setId(generateUniqueId());
        groups.put(group.getId(), group);
    }
    
    /**
     * Retrieves a group from the database by looking up its unique database index.
     * @param index the database id of the record
     * @return the in-memory group object stored in the database
     */
    public static Group read(int index) {
        return groups.get(index);
    }
    
    /**
     * Replaces the group in the database.
     * Replaces the existing object that has the same database id.
     * @param group the group - with a valid id - to update in the database
     */
    public static void update(Group group) {
        groups.put(group.getId(), group);
    }
    
    /**
     * Deletes the group in the database that matches the supplied databas id.
     * @param index the unique database id of the group to delete
     */
    public static void delete(int index) {
        groups.remove(index);
    }
    
}
