package au.edu.uts.aip.waitinglist;

import java.io.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A backing bean for newgroup, editgroup and deletegroup JSF views.
 */
@Named
@RequestScoped
public class GroupController implements Serializable {

    private Group group = new Group();

    /**
     * The group/model that our controller will manipulate.
     * @return 
     */
    public Group getGroup() {
        return group;
    }

    /**
     * Load the details of a group from the database.
     * @param index the unique database id of the group to retrieve
     */
    public void loadGroup(int index) {
        group = WaitingListDatabase.read(index);
    }
    
    /**
     * Save the current group as a new record in the database.
     * @return a redirect to view the whole waiting list
     */
    public String saveAsNew() {
        WaitingListDatabase.create(group);
        return "waitinglist?faces-redirect=true";
    }
    
    /**
     * Update the record in the database whose database id matches that of the current group.
     * @return a redirect to view the whole waiting list
     */
    public String saveChanges() {
        WaitingListDatabase.update(group);
        return "waitinglist?faces-redirect=true";
    }
    
    /**
     * Delete the record from the database that matches the current group's database id.
     * @return a redirect to view the whole waiting list
     */
    public String delete() {
        WaitingListDatabase.delete(group.getId());
        return "waitinglist?faces-redirect=true";
    }
    
}