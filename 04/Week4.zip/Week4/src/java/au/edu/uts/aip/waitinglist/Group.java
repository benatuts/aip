package au.edu.uts.aip.waitinglist;

import java.io.*;
import javax.validation.constraints.*;

/**
 * A bean that represents a booking in the waiting list.
 * Each group has a name, group size (number of people) and a unique database ID.
 * The database ID will be set by the database automatically.
 */
public class Group implements Serializable {

    private int id;
    private String name;
    private int size;
    
    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    @Size(min = 1)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Min(1)
    @Max(20)
    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    
}
