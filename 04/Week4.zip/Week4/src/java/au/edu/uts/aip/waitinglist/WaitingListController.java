package au.edu.uts.aip.waitinglist;

import java.io.*;
import java.util.*;
import javax.enterprise.context.*;
import javax.inject.*;

/**
 * A backing bean for the waitinglist JSF view.
 */
@Named
@RequestScoped
public class WaitingListController implements Serializable {
    
    /**
     * Returns a collection containing the entire waiting list database.
     * @return 
     */
    public Collection<Group> getGroups() {
        return WaitingListDatabase.findAll();
    }
    
}
